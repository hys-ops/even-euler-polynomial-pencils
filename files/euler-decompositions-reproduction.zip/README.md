# Functional decompositions of even Euler polynomial pencils

This archive contains only the anonymous Euler manuscript (PDF and LaTeX), its Lean project, the archived verification log and the independent Python check. No Tutte files or compiled objects are included.

With elan and Python 3 installed, run:

    cd formal/euler
    lake exe cache get
    lake env python3 verify.py --kernel

Lean 4.34.1 and mathlib d13f23b723b8a846827a245b89c10fc7d3f11612 are pinned. The script compiles the 27 local modules into a fresh temporary directory, checks the axioms of the 13 public declarations and runs the kernel replay of the local declarations. It does not rebuild all of mathlib. The included log records the original run, not a new replay of this packaging. All Lean sources are unchanged.

From the archive root, run `python3 checks/check_euler_exceptions.py` for the four single-point certificates. Run pdflatex twice in manuscript/ to build the anonymous LaTeX source. Verify the file manifest with `sha256sum -c SHA256SUMS`.
