"""Reproduce the four exceptional-prime rows in the Euler manuscript.

Uses the finite alternating-shift identity for the centered Euler polynomials
and Euler's criterion. Python 3, no third-party dependencies.
"""
from math import isqrt


def delta(degree, point, modulus):
    return sum(
        (-1)**j * (pow(point + 2*j + 1, degree, modulus)
                   - pow(2*j + 1, degree, modulus))
        for j in range(modulus)
    ) % modulus


def main():
    print("p  q  z  delta(2p-2)  delta(2p)  quadratic_character")
    for p, q, z, expected in [(3, 19, 5, 12), (5, 97, 3, 92),
                              (7, 19, 8, 10), (11, 29, 3, 11)]:
        if q < 3 or any(q % j == 0 for j in range(2, isqrt(q) + 1)):
            raise ValueError(f"{q} is not an odd prime")
        low = delta(2*p - 2, z, q)
        high = delta(2*p, z, q)
        character = pow(high, (q - 1)//2, q)
        if (low, high, character) != (0, expected, q - 1):
            raise ArithmeticError(f"certificate failed for p={p}")
        print(p, q, z, low, high, -1)


if __name__ == "__main__":
    main()
