import EulerPrime
import EulerNormalized
import Mathlib.Algebra.Polynomial.Derivative

namespace EulerIdentification
open Polynomial Finset
open EulerPrime EulerNormalized
open scoped BigOperators

private theorem A0 : A ℤ 0 = 1 := by rw [A.eq_1]; simp

private theorem at_zero (n : ℕ) : (A ℤ n).eval 0 = secant n := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    cases n with
    | zero => simp [A0,secant.eq_1]
    | succ n =>
      rw [A,secant]
      simp only [eval_sub,eval_pow,eval_X,zero_pow (Nat.succ_ne_zero _),zero_sub,
        eval_finsetSum,apply_ite (eval _),eval_mul,eval_natCast,eval_zero]
      by_cases hmod : (n+1)%2=1
      · rw [if_pos hmod]
        apply neg_eq_zero.mpr
        apply Finset.sum_eq_zero
        intro j _
        split_ifs with h
        · rw [ih j j.isLt,secant_odd]
          · simp
          · obtain ⟨k,hk⟩ := h
            have := j.isLt
            omega
        · rfl
      · rw [if_neg hmod]
        congr 1
        apply Finset.sum_congr rfl
        intro j _
        split_ifs with h
        · rw [ih j j.isLt]
        · rw [secant_odd]
          · simp
          · by_contra! he
            apply h
            exact ⟨((n+1)-j.val)/2, by have := j.isLt; omega⟩


private noncomputable def termA (m j : ℕ) : ℤ[X] :=
  if Even (m-j) then (m.choose j : ℤ[X])*A ℤ j else 0

private theorem appellA (n : ℕ) :
    derivative (A ℤ (n+1)) = C ((n+1:ℕ):ℤ) * A ℤ n := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    rw [A.eq_1 ℤ (n+1)]
    conv_rhs => rw [A.eq_1 ℤ n]
    change derivative (X^(n+1) - ∑ j : Fin (n+1), termA (n+1) j.val) =
      C ((n+1:ℕ):ℤ) * (X^n - ∑ j : Fin n, termA n j.val)
    rw [derivative_sub, derivative_X_pow, derivative_sum, Fin.sum_univ_succ]
    have hzero : derivative (termA (n+1) 0) = 0 := by
      unfold termA
      split_ifs <;> simp [A0]
    simp only [Fin.val_zero, Fin.val_succ, hzero, zero_add, Nat.add_sub_cancel, mul_sub,Finset.mul_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    unfold termA
    by_cases hj : Even (n-j.val)
    · have hj' : Even (n+1-(j.val+1)) := by simpa using hj
      rw [if_pos hj',if_pos hj, ← C_eq_natCast,derivative_C_mul,ih j j.isLt]
      rw [← C_eq_natCast (n.choose j)]
      rw [← mul_assoc, ← mul_assoc, ← map_mul, ← map_mul]
      congr 2
      exact_mod_cast (Nat.add_one_mul_choose_eq n j).symm
    · have hj' : ¬Even (n+1-(j.val+1)) := by simpa using hj
      simp [hj',hj]


/-- Identification of the centered Euler polynomial defined by inverse shifts
with the independent construction from integer secant Euler numbers. -/
theorem centered_eq_A (n : ℕ) : centered n = A ℤ n := by
  induction n with
  | zero =>
    ext k
    rw [coeff_centered,A0]
    cases k <;> simp [secant.eq_1,coeff_one]
  | succ n ih =>
    ext k
    cases k with
    | zero =>
      rw [coeff_centered, coeff_zero_eq_eval_zero, at_zero]
      simp
    | succ k =>
      have h := congrArg (fun P : ℤ[X] => P.coeff k) (appellA n)
      simp only [coeff_derivative, coeff_C_mul] at h
      rw [← ih, coeff_centered] at h
      rw [coeff_centered, Nat.succ_sub_succ_eq_sub]
      have hk : (k+1 : ℤ) ≠ 0 := by positivity
      apply mul_right_cancel₀ hk
      have hbin : ((n+1).choose (k+1):ℤ) * ((k:ℤ)+1) =
          ((n:ℤ)+1) * (n.choose k:ℤ) := by exact_mod_cast (Nat.add_one_mul_choose_eq n k).symm
      push_cast at h
      linear_combination (secant (n-k)) * hbin - h

theorem delta_eq_A_sub_const (n : ℕ) :
    delta n = A ℤ n - C ((A ℤ n).eval 0) := by
  rw [at_zero, ← centered_eq_A, centered_sub_const]

#print axioms centered_eq_A
#print axioms delta_eq_A_sub_const

end EulerIdentification
