import Mathlib.Data.Nat.Choose.Lucas
import Mathlib.Algebra.Polynomial.Eval.Coeff
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum

import Mathlib.Algebra.Field.ZMod
import Mathlib.Algebra.Polynomial.Degree.Domain
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Algebra.Prime.Lemmas
import Mathlib.Data.Nat.Prime.Int

namespace EulerPrime
open Polynomial Finset

private theorem central {p : ℕ} [Fact p.Prime] :
    (((2*p).choose p : ℕ) : ZMod p) = 2 := by
  have h := Choose.choose_mul_mul_modEq_choose (p := p) (a := 2) (b := 1)
  have h' := (ZMod.intCast_eq_intCast_iff _ _ _).mpr h
  simpa [mul_comm] using h'

private theorem lowerBinom {p : ℕ} [Fact p.Prime] (h : 2 < p) :
    p ∣ (2*p-2).choose (p-1) := by
  have h' := Choose.choose_modEq_choose_mod_mul_choose_div_nat (p := p)
      (n := 2*p-2) (k := p-1)
  have h1 : (2*p-2)%p = p-2 := by
    rw [show 2*p-2 = (p-2)+p from by omega, Nat.add_mod_right, Nat.mod_eq_of_lt (by omega)]
  have h2 : (p-1)%p = p-1 := Nat.mod_eq_of_lt (by omega)
  rw [h1, h2, Nat.choose_eq_zero_of_lt (show p-2 < p-1 by omega), zero_mul] at h'
  exact Nat.modEq_zero_iff_dvd.mp h'

/-- The first neighboring coefficient contains exactly one copy of p. -/
theorem binom_not_dvd_sq {p : ℕ} [Fact p.Prime] (hp : 2 < p) :
    ¬ (p:ℤ)^2 ∣ ((2*p).choose (p-1) : ℤ) := by
  intro hd
  have hrel := Nat.choose_succ_right_eq (2*p) (p-1)
  rw [show p-1+1=p from by omega, show 2*p-(p-1)=p+1 from by omega] at hrel
  have hrel' : ((2*p).choose p : ℤ)*p=((2*p).choose (p-1):ℤ)*(p+1) := by exact_mod_cast hrel
  obtain ⟨k,hk⟩ := hd
  have hpz : (p:ℤ) ≠ 0 := by exact_mod_cast (by omega : p ≠ 0)
  have hc : ((2*p).choose p : ℤ) = (p:ℤ)*(k*(p+1)) := by
    apply mul_right_cancel₀ hpz
    rw [hrel',hk]
    ring
  have hd' := (ZMod.intCast_zmod_eq_zero_iff_dvd ((2*p).choose p) p).mpr ⟨_,hc⟩
  have he := central (p := p)
  push_cast at hd'
  rw [he] at hd'
  have hd2 : p ∣ 2 := (ZMod.natCast_eq_zero_iff 2 p).mp (by simpa using hd')
  exact (not_le_of_gt hp) (Nat.le_of_dvd (by decide) hd2)

/-- A square reducing to X^(2p) has its coefficient at p-1 divisible by p². -/
theorem square_low_coeff {p : ℕ} [Fact p.Prime] (S : ℤ[X])
    (hs : (S.map (Int.castRingHom (ZMod p)))^2 = (X: (ZMod p)[X])^(2*p)) :
    (p:ℤ)^2 ∣ (S^2).coeff (p-1) := by
  have hp := (Fact.out : p.Prime).pos
  have hl (k : ℕ) (hk : k < p) : (p:ℤ) ∣ S.coeff k := by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp
    have hsq : (S.map (Int.castRingHom (ZMod p)))^2 = ((X : (ZMod p)[X])^p)^2 := by
      simpa [← pow_mul, mul_comm] using hs
    rcases sq_eq_sq_iff_eq_or_eq_neg.mp hsq with h | h
    all_goals
      have hcoeff := congrArg (fun f : (ZMod p)[X] => f.coeff k) h
      simpa [coeff_map, coeff_X_pow, hk.ne] using hcoeff
  rw [show S^2 = S*S by ring, coeff_mul]
  apply Finset.dvd_sum
  intro ij hij
  have hij' := Finset.mem_antidiagonal.mp hij
  rw [pow_two]
  exact mul_dvd_mul (hl _ (by omega)) (hl _ (by omega))


/-- Obstruction for the normalized Euler coefficient at p-1. The next result
specializes this test to the coefficient expansion of the Euler sequence. -/
theorem no_square_of_coeff {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (S : ℤ[X]) (d u v : ℤ) (hd : (p:ℤ) ∣ d) (hu : ¬(p:ℤ) ∣ u)
    (hs : (S.map (Int.castRingHom (ZMod p)))^2 = (X: (ZMod p)[X])^(2*p))
    (hc : (S^2).coeff (p-1) =
        ((2*p).choose (p-1) : ℤ)*u + d*((2*p-2).choose (p-1):ℤ)*v) : False := by
  have h := square_low_coeff S hs
  rw [hc] at h
  have hb : (p:ℤ) ∣ ((2*p-2).choose (p-1):ℤ) := by exact_mod_cast lowerBinom hp
  have h2 : (p:ℤ)^2 ∣ d*((2*p-2).choose (p-1):ℤ)*v := by
    rw [pow_two]
    exact dvd_mul_of_dvd_left (mul_dvd_mul hd hb) _
  have h3 := (dvd_add_left h2).mp h
  exact binom_not_dvd_sq hp
    ((Nat.prime_iff_prime_int.mp (Fact.out : p.Prime)).pow_dvd_of_dvd_mul_right 2 hu h3)


/-- Integer secant Euler numbers, fixed by sech(t) cosh(t) = 1. -/
def secant : ℕ → ℤ
  | 0 => 1
  | n+1 => if (n+1)%2 = 1 then 0 else
      -∑ i : Fin (n+1), ((n+1).choose i.val : ℤ) * secant i.val
termination_by n => n
decreasing_by exact i.isLt

theorem secant_odd {k : ℕ} (hk : k%2=1) : secant k = 0 := by
  cases k with
  | zero => omega
  | succ k => rw [secant]; simp [hk]

private theorem succ_binom {p k : ℕ} [Fact p.Prime] (hp : 2 < p)
    (hk2 : 2 ≤ k) (hk : k < p) : p ∣ (p+1).choose k := by
  have h := Choose.choose_modEq_choose_mod_mul_choose_div_nat (p := p) (n := p+1) (k := k)
  have hr : (p+1)%p=1 := by
    rw [add_comm, Nat.add_mod_right, Nat.mod_eq_of_lt (by omega)]
  rw [hr, Nat.mod_eq_of_lt hk, Nat.choose_eq_zero_of_lt (show 1 < k by omega), zero_mul] at h
  exact Nat.modEq_zero_iff_dvd.mp h

theorem secant_succ_prime {p : ℕ} [Fact p.Prime] (hp : 2 < p) :
    (secant (p+1) : ZMod p) = -1 := by
  have hodd := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  have hmod : p%2=1 := Nat.odd_iff.mp hodd
  have hmod' : (p+1)%2 ≠ 1 := by omega
  rw [secant, if_neg hmod']
  push_cast
  rw [Finset.sum_eq_single (0 : Fin (p+1))]
  · simp [secant]
  · intro j hj h0
    have h0' : j.val ≠ 0 := fun hj0 => h0 (Fin.ext hj0)
    by_cases h1 : j.val = 1
    · simp [h1, secant_odd (k := 1) (by decide)]
    by_cases he : j.val = p
    · simp [he, secant_odd hmod]
    have hd := succ_binom hp (k := j.val) (by omega) (by have := j.isLt; omega)
    simp [(ZMod.natCast_eq_zero_iff _ p).2 hd]
  · simp

/-- The centered Euler polynomial after removing its constant term. -/
noncomputable def delta (m : ℕ) : ℤ[X] :=
  ∑ k ∈ Finset.range (m+1),
    monomial k (if k = 0 then 0 else (m.choose k : ℤ)*secant (m-k))

theorem coeff_delta (m k : ℕ) : (delta m).coeff k =
    if k ≤ m ∧ k ≠ 0 then (m.choose k:ℤ)*secant (m-k) else 0 := by
  classical
  simp only [delta,finsetSum_coeff,coeff_monomial]
  by_cases hk : k ≤ m
  · have hm : k ∈ Finset.range (m+1) := by simp; omega
    rw [Finset.sum_eq_single_of_mem k hm]
    · by_cases hz : k = 0 <;> simp [hk,hz]
    · intro b hb hbk
      simp [hbk]
  · have hg : m < k := by omega
    rw [Finset.sum_eq_zero]
    · simp [hk]
    · intro b hb
      have hbk : b ≠ k := by simp at hb; omega
      simp [hbk]


private theorem twice_prime_binom {p k : ℕ} [Fact p.Prime] (_hp : 2 < p)
    (hk0 : 0 < k) (hkp : k ≠ p) (hk : k < 2*p) : p ∣ (2*p).choose k := by
  have h := Choose.choose_modEq_choose_mod_mul_choose_div_nat (p := p) (n := 2*p) (k := k)
  have hr : 0 < k%p := by
    by_cases hl : k < p
    · rwa [Nat.mod_eq_of_lt hl]
    · have hd : k-p < p := by omega
      rw [show k = (k-p)+p from by omega, Nat.add_mod_right, Nat.mod_eq_of_lt hd]
      omega
  rw [Nat.mul_mod_left, Nat.choose_eq_zero_of_lt hr, zero_mul] at h
  exact Nat.modEq_zero_iff_dvd.mp h

/-- Polynomial identity, stronger than equality of values on the prime field. -/
theorem delta_twice_prime {p : ℕ} [Fact p.Prime] (hp : 2 < p) :
    (delta (2*p)).map (Int.castRingHom (ZMod p)) = (X : (ZMod p)[X])^(2*p) := by
  ext k
  rw [coeff_map,coeff_delta,coeff_X_pow]
  change (↑(if k ≤ 2*p ∧ k ≠ 0 then (((2*p).choose k : ℤ)*secant (2*p-k)) else 0) : ZMod p) = _
  by_cases he : k = 2*p
  · subst k
    have h : 2*p ≠ 0 := by omega
    simp [h, secant]
  · by_cases h : k ≤ 2*p ∧ k ≠ 0
    · simp only [if_pos h, if_neg he, Int.cast_mul, Int.cast_natCast]
      by_cases he' : k=p
      · subst k
        rw [show 2*p-p = p from by omega,
          secant_odd (Nat.odd_iff.mp ((Fact.out : p.Prime).odd_of_ne_two (by omega)))]
        simp
      · have hb := twice_prime_binom hp (k:=k) (by omega) he' (by omega)
        simp [(ZMod.natCast_eq_zero_iff _ _).2 hb]
    · simp [h,he]

/-- If p divides the integer parameter d, the normalized Euler difference
of degree 2p is not a square in the integer polynomial ring. -/
theorem no_euler_square_of_prime_dvd {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (d : ℤ) (hd : (p:ℤ) ∣ d) :
    ¬ ∃ S : ℤ[X], S^2 = delta (2*p) + C d * delta (2*p-2) := by
  rintro ⟨S,hS⟩
  have hdp := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr hd
  apply no_square_of_coeff hp S d (secant (p+1)) (secant (p-1)) hd
  · intro hz
    have hz' := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mpr hz
    rw [secant_succ_prime hp] at hz'
    simp at hz'
  · have hh := congrArg (fun f : ℤ[X] => f.map (Int.castRingHom (ZMod p))) hS
    have hdP : (d : (ZMod p)[X]) = 0 := by rw [← C_eq_intCast, hdp, map_zero]
    simpa [Polynomial.map_pow,Polynomial.map_add,Polynomial.map_mul,delta_twice_prime hp,hdP] using hh
  · have hh := congrArg (fun f : ℤ[X] => f.coeff (p-1)) hS
    have h1 : p-1 ≤ 2*p ∧ p-1 ≠ 0 := by omega
    have h2 : p-1 ≤ 2*p-2 ∧ p-1 ≠ 0 := by omega
    simpa [coeff_add, coeff_C_mul, coeff_delta, h1, h2, show 2*p-(p-1)=p+1 from by omega,
      show 2*p-2-(p-1)=p-1 from by omega, mul_assoc] using hh

/-- The full centered Euler polynomial, with its constant term restored. -/
noncomputable def centered (m : ℕ) : ℤ[X] := delta m + C (secant m)

theorem coeff_centered (m k : ℕ) :
    (centered m).coeff k = (m.choose k : ℤ) * secant (m-k) := by
  rw [centered, coeff_add, coeff_delta, coeff_C]
  by_cases h0 : k = 0
  · subst k; simp
  · by_cases hk : k ≤ m
    · simp [h0, hk]
    · simp [h0, hk, Nat.choose_eq_zero_of_lt (Nat.lt_of_not_ge hk)]

theorem centered_sub_const (m : ℕ) :
    centered m - C (secant m) = delta m := by simp [centered]

theorem delta_natDegree {m : ℕ} (hm : 0 < m) : (delta m).natDegree = m := by
  apply natDegree_eq_of_le_of_coeff_ne_zero
  · apply natDegree_le_iff_coeff_eq_zero.mpr
    intro n hn
    simp [coeff_delta, Nat.not_le.mpr hn]
  · simp [coeff_delta, hm.ne',secant.eq_1]

theorem delta_monic {m : ℕ} (hm : 0 < m) : (delta m).Monic := by
  change (delta m).coeff (delta m).natDegree = 1
  simp [delta_natDegree hm, coeff_delta, hm.ne',secant.eq_1]

theorem delta_coeff_even {m k : ℕ} (hm : Even m) (hk : Odd k) : (delta m).coeff k = 0 := by
  rw [coeff_delta]
  split_ifs with h
  · obtain ⟨u,hu⟩ := hm
    obtain ⟨v,hv⟩ := hk
    rw [secant_odd (show (m-k)%2=1 from by omega),mul_zero]
  · rfl

#print axioms no_euler_square_of_prime_dvd

end EulerPrime
