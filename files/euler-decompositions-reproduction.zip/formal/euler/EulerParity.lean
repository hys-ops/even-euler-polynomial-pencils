import EulerParitySet
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination

/-! Alternating binomial coordinates on the residue field and their second and fourth moments. -/
namespace EulerParity
open Finset

section Prefix
variable {K : Type*} [CommRing K]

/-- Discrete Euler summation: any polynomial antiderivative of the two-point
    averaging operator telescopes along the odd progression with alternating signs. -/
theorem alternatingPrefix (P : K → K) (k m : ℕ)
    (h : ∀ x : K, P x + P (x+2) = 2 * (x+1)^k) :
    2 * (∑ j ∈ range m, (-1:K)^j * (2*(j:K)+1)^k) =
      P 0 - (-1:K)^m * P (2*(m:K)) := by
  induction m with
  | zero => simp
  | succ m ih =>
    rw [sum_range_succ, mul_add, ih, pow_succ, Nat.cast_succ]
    rw [show 2*((m:K)+1) = 2*(m:K)+2 by ring]
    linear_combination - ((-1:K)^m) * h (2*(m:K))

/-- Ordinary sums on the same progression. The integer multipliers avoid division. -/
theorem ordinaryPrefix (m : ℕ) :
    3 * (∑ j ∈ range m, (2*(j:K)+1)^2) = (m:K)*(4*(m:K)^2-1) ∧
    15 * (∑ j ∈ range m, (2*(j:K)+1)^4) =
      (m:K)*(48*(m:K)^4 - 40*(m:K)^2 + 7) := by
  induction m with
  | zero => simp
  | succ m ih =>
    simp only [sum_range_succ, mul_add, Nat.cast_succ]
    rw [ih.1,ih.2]
    constructor <;> ring

end Prefix

/-- A residue characteristic above five does not kill the integral factors
    needed to recover either ordinary power sum. -/
private theorem cast_nonzero_of_small {p : ℕ} (h5 : 5 < p) {n : ℕ}
    (hn : 0 < n) (hs : n ≤ 5) : (n : ZMod p) ≠ 0 := by
  intro he
  have hd := (ZMod.natCast_eq_zero_iff n p).mp he
  have := Nat.le_of_dvd hn hd
  omega

private theorem odd_prime {p : ℕ} [Fact p.Prime] (h5 : 5 < p) : p % 2 = 1 := by
  obtain ⟨t,ht⟩ := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  omega

/-- The alternating even-power sums on all odd coordinates are the Euler
    constants e₂ = −1 and e₄ = 5 in the residue field. -/
theorem alternatingEulerConstants {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    (∑ j ∈ range p, (-1:ZMod p)^j * (2*(j:ZMod p)+1)^2) = -1 ∧
    (∑ j ∈ range p, (-1:ZMod p)^j * (2*(j:ZMod p)+1)^4) = 5 := by
  have hp : Odd p := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  have h2 : (2 : ZMod p) ≠ 0 := cast_nonzero_of_small h5 (n := 2) (by decide) (by decide)
  have h := alternatingPrefix (K:=ZMod p) (fun x => x^2-1) 2 p (fun x => by ring)
  have h' := alternatingPrefix (K:=ZMod p) (fun x => x^4-6*x^2+5) 4 p (fun x => by ring)
  simp only [CharP.cast_eq_zero (ZMod p) p, mul_zero, hp.neg_one_pow] at h h'
  constructor
  · apply mul_left_cancel₀ h2
    linear_combination h
  · apply mul_left_cancel₀ h2
    linear_combination h'

private theorem ordinaryZero {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    (∑ j ∈ range p, (2*(j:ZMod p)+1)^2) = 0 ∧
    (∑ j ∈ range p, (2*(j:ZMod p)+1)^4) = 0 := by
  have ⟨h,h'⟩ := ordinaryPrefix (K:=ZMod p) p
  simp only [CharP.cast_eq_zero (ZMod p) p, zero_mul] at h h'
  have h3 : (3 : ZMod p) ≠ 0 := cast_nonzero_of_small h5 (n:=3) (by decide) (by decide)
  have h5' : (5 : ZMod p) ≠ 0 := cast_nonzero_of_small h5 (n:=5) (by decide) (by decide)
  have h15 : (15 : ZMod p) ≠ 0 := by
    rw [show (15 : ZMod p) = 3*5 from by norm_num]
    exact mul_ne_zero h3 h5'
  exact ⟨(mul_eq_zero.mp h).resolve_left h3, (mul_eq_zero.mp h').resolve_left h15⟩

/-- Pointwise identity for the selected parity, written without division by two. -/
private theorem indicator {p : ℕ} [Fact p.Prime] (h5 : 5 < p) (j : ℕ) (u : ZMod p) :
    2*(if j%2 ≠ (p/2)%2 then u else 0) =
      u - (if p%4=1 then 1 else -1:ZMod p) * ((-1:ZMod p)^j * u) := by
  have ho := odd_prime h5
  rcases Nat.even_or_odd j with he|hh
  · rw [he.neg_one_pow, show j%2 = 0 from by obtain ⟨t,ht⟩ := he; omega]
    by_cases hp : p%4=1
    · simp [hp, show (p/2)%2=0 from by omega]
    · simp [hp, show (p/2)%2=1 from by omega]; ring
  · rw [hh.neg_one_pow, show j%2 = 1 from by obtain ⟨t,ht⟩ := hh; omega]
    by_cases hp : p%4=1
    · simp [hp, show (p/2)%2=0 from by omega]; ring
    · simp [hp, show (p/2)%2=1 from by omega]

private theorem filteredMoment {p : ℕ} [Fact p.Prime] (h5 : 5<p)
    (f : ℕ → ZMod p) :
    2*(∑ j ∈ (range p).filter (fun j => j%2 ≠ (p/2)%2), f j) =
      (∑ j ∈ range p, f j) - (if p%4=1 then 1 else -1:ZMod p) *
      (∑ j ∈ range p, (-1:ZMod p)^j * f j) := by
  rw [sum_filter, mul_sum, mul_sum, ← sum_sub_distrib]
  apply sum_congr rfl
  intro j _
  exact indicator h5 j (f j)

/-- The second and fourth moments of the concrete parity half of F_p. -/
theorem secondFourth {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    2 * (∑ z ∈ B p, z^2) = (if p%4=1 then 1 else -1 : ZMod p) ∧
    2 * (∑ z ∈ B p, z^4) = -5 * (if p%4=1 then 1 else -1 : ZMod p) := by
  have hm₂ := filteredMoment h5 (fun j => (2*(j:ZMod p)+1)^2)
  have hm₄ := filteredMoment h5 (fun j => (2*(j:ZMod p)+1)^4)
  obtain ⟨ha₂,ha₄⟩ := alternatingEulerConstants h5
  obtain ⟨hu₂,hu₄⟩ := ordinaryZero h5
  rw [ha₂,hu₂] at hm₂
  rw [ha₄,hu₄] at hm₄
  rw [B, Finset.sum_image (coord_inj h5), Finset.sum_image (coord_inj h5)]
  simp only [coord, even_two.neg_pow, (show Even 4 from ⟨2,rfl⟩).neg_pow, indices]
  constructor
  · linear_combination hm₂
  · linear_combination hm₄

#print axioms alternatingEulerConstants
#print axioms secondFourth
end EulerParity
