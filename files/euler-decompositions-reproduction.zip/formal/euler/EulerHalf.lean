import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.BigOperators.Group.Finset.Sigma
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-! Hyperbola fibres and square values over finite fields of odd characteristic.
Zero is included as a square. -/
namespace EulerHalf

open Finset
variable {K : Type*} [Field K] [Fintype K] [DecidableEq K]

def sqValues (a : K) : Finset K :=
  Finset.univ.filter fun z => ∃ y : K, y^2 = z^2 + a

def zeroValues (a : K) : Finset K :=
  Finset.univ.filter fun z => z^2 + a = 0

omit [Fintype K] [DecidableEq K] in
private theorem neq_neg (h2 : (2 : K) ≠ 0) {x : K} (hx : x ≠ 0) : x ≠ -x := by
  intro he
  have hh : (2:K)*x = 0 := by linear_combination he
  exact (mul_ne_zero h2 hx) hh

private theorem fiber_card {b : K} (h2 : (2 : K) ≠ 0) :
    Fintype.card {y : K // y^2 = b} =
      if b = 0 then 1 else if ∃ y : K, y^2 = b then 2 else 0 := by
  rw [Fintype.card_subtype]
  by_cases hb : b = 0
  · subst b
    have hs : Finset.univ.filter (fun x : K => x^2 = 0) = {0} := by ext x; simp
    rw [hs]; simp
  · rw [if_neg hb]
    by_cases he : ∃ y : K, y^2 = b
    · simp only [if_pos he]
      obtain ⟨y,hy⟩ := he
      have h0 : y ≠ 0 := by intro h; apply hb; simp [← hy,h]
      have hs : (Finset.univ.filter (fun x : K => x^2 = b)) = {y,-y} := by
        ext x
        simp [← hy, sq_eq_sq_iff_eq_or_eq_neg]
      rw [hs, Finset.card_pair (neq_neg h2 h0)]
    · rw [if_neg he]
      apply Finset.card_eq_zero.mpr
      simpa using he

/-- The parameter is w=y+z, with z=(w-a/w)/2 and y=(w+a/w)/2. -/
noncomputable def hyperbolaParam (a : K) (ha : a ≠ 0) (h2 : (2:K) ≠ 0) :
    Kˣ ≃ Σ z : K, {y : K // y^2 = z^2 + a} where
  toFun w := ⟨((w:K)-a/(w:K))/2, ((w:K)+a/(w:K))/2, by
    field_simp [w.ne_zero,h2]
    <;> ring⟩
  invFun u := Units.mk0 (u.2.1+u.1) (by
    intro he
    apply ha
    calc
      a = (u.2.1+u.1)*(u.2.1-u.1) := by linear_combination -u.2.2
      _ = 0 := by rw [he,zero_mul])
  left_inv w := by
    apply Units.ext
    change ((w:K)+a/(w:K))/2 + ((w:K)-a/(w:K))/2 = (w:K)
    field_simp [w.ne_zero,h2]; ring
  right_inv := by
    rintro ⟨z,y,hy⟩
    have hsum : y+z ≠ 0 := by
      intro he
      apply ha
      calc
        a = (y+z)*(y-z) := by linear_combination -hy
        _ = 0 := by rw [he,zero_mul]
    have hd : a/(y+z) = y-z := by
      apply (div_eq_iff hsum).2
      linear_combination -hy
    change (⟨((y+z)-a/(y+z))/2, ⟨((y+z)+a/(y+z))/2, _⟩⟩ :
      Σ z : K, {y : K // y^2 = z^2 + a}) = ⟨z,⟨y,hy⟩⟩
    have hfst : ((y+z)-a/(y+z))/2 = z := by rw [hd]; field_simp [h2]; ring
    have hsnd : ((y+z)+a/(y+z))/2 = y := by rw [hd]; field_simp [h2]; ring
    apply Sigma.ext hfst
    exact (Subtype.heq_iff_coe_eq
      (p := fun u : K => u^2 = (((y+z)-a/(y+z))/2)^2+a)
      (q := fun u : K => u^2 = z^2+a) (fun _ => by rw [hfst])).mpr hsnd

/-- Both the count and all weighted sums, including second and fourth powers.
The second sum restores the missing copy at the one-point fibres. -/
theorem weightedFiber {M : Type*} [AddCommMonoid M] (f : K → M) (a : K)
    (ha : a ≠ 0) (h2 : (2:K) ≠ 0) :
    (∑ w : Kˣ, f (((w:K)-a/(w:K))/2)) + ∑ z ∈ zeroValues a, f z =
      2 • (∑ z ∈ sqValues a, f z) := by
  classical
  have hu := Fintype.sum_equiv (hyperbolaParam a ha h2)
    (fun w : Kˣ => f (((w:K)-a/(w:K))/2)) (fun u => f u.1) (fun _ => rfl)
  rw [hu, Fintype.sum_sigma]
  simp only [Finset.sum_const, Finset.card_univ, zeroValues, sqValues, Finset.sum_filter]
  rw [← Finset.sum_add_distrib, two_nsmul, ← Finset.sum_add_distrib]
  apply Finset.sum_congr rfl
  intro z _
  rw [fiber_card h2]
  by_cases hz : z^2+a=0
  · have he : ∃ y : K, y^2 = z^2+a := ⟨0,by simp [hz]⟩
    simp [hz,he,two_nsmul]
  · by_cases he : ∃ y : K, y^2=z^2+a <;> simp [hz,he,two_nsmul]

theorem cardSquareValues (a : K) (ha : a ≠ 0) (h2 : (2:K) ≠ 0) :
    Fintype.card K - 1 + (zeroValues a).card = 2 * (sqValues a).card := by
  simpa [Fintype.card_units] using weightedFiber (M:=ℕ) (fun _ : K => 1) a ha h2

theorem cardZeroValues (a : K) (ha : a ≠ 0) (h2 : (2:K) ≠ 0) :
    (zeroValues a).card = 0 ∨ (zeroValues a).card = 2 := by
  have hs : zeroValues a = Finset.univ.filter (fun z : K => z^2 = -a) := by
    ext; simp [zeroValues,eq_neg_iff_add_eq_zero]
  rw [hs, ← Fintype.card_subtype, fiber_card h2, if_neg (neg_ne_zero.mpr ha)]
  split <;> simp

/-- If a sign-symmetric lower half fits inside W, it already contains every
nonzero element of W. The size hypothesis holds for either possible half. -/
theorem onlyZeroMissing (a : K) (ha : a ≠ 0) (h2 : (2:K) ≠ 0)
    (B : Finset K) (hB : Fintype.card K ≤ 2*B.card+1)
    (hs : ∀ z, z ∈ B ↔ -z ∈ B) (hsub : B ⊆ sqValues a) :
    ∀ z ∈ sqValues a, z ∉ B → z=0 := by
  have hW := cardSquareValues a ha h2
  have hZ := cardZeroValues a ha h2
  have hsW : (sqValues a \ B).card ≤ 1 := by
    rw [Finset.card_sdiff_of_subset hsub]
    rcases hZ with hz | hz <;> omega
  intro z hzw hzb
  by_contra hz
  have hnegw : -z ∈ sqValues a := by simpa [sqValues] using hzw
  have heq := Finset.card_le_one.mp hsW z (Finset.mem_sdiff.mpr ⟨hzw,hzb⟩)
    (-z) (Finset.mem_sdiff.mpr ⟨hnegw,fun h => hzb ((hs z).mpr h)⟩)
  exact neq_neg h2 hz heq

theorem lowerHalfMoments {M : Type*} [AddCommMonoid M] (f : K → M) (hf : f 0 = 0)
    (a : K) (ha : a ≠ 0) (h2 : (2:K) ≠ 0)
    (B : Finset K) (hB : Fintype.card K ≤ 2*B.card+1)
    (hs : ∀ z, z ∈ B ↔ -z ∈ B) (hsub : B ⊆ sqValues a) :
    (∑ w : Kˣ, f (((w:K)-a/(w:K))/2)) + ∑ z ∈ zeroValues a, f z =
      2 • (∑ z ∈ B, f z) := by
  rw [weightedFiber f a ha h2]
  congr 1
  symm
  apply Finset.sum_subset hsub
  intro z hw hn
  rw [onlyZeroMissing a ha h2 B hB hs hsub z hw hn, hf]

#print axioms weightedFiber
#print axioms lowerHalfMoments
end EulerHalf
