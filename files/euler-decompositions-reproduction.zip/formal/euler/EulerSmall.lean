import EulerNormalized
import EulerMoments

/-! The normalized Euler pencil, its specialization under coefficient maps,
and the exceptional degree test on the actual polynomial modulo 23. -/
namespace EulerSmall
open Polynomial

local instance : Fact (Nat.Prime 23) := ⟨by decide⟩

noncomputable def delta (R : Type*) [CommRing R] (m : ℕ) : R[X] :=
  EulerNormalized.A R m - C ((EulerNormalized.A R m).eval 0)

noncomputable def pencil (R : Type*) [CommRing R] (p : ℕ) (d : R) : R[X] :=
  delta R (2*p) + C d * delta R (2*p-2)

theorem map_delta {R S : Type*} [CommRing R] [CommRing S] (f : R →+* S) (m : ℕ) :
    (delta R m).map f = delta S m := by
  have h := Polynomial.eval_map_apply (f:=f) (p:=EulerNormalized.A R m) (0:R)
  rw [map_zero,EulerNormalized.map_A] at h
  simp [delta, EulerNormalized.map_A, h]

theorem map_pencil {R S : Type*} [CommRing R] [CommRing S] (f : R →+* S)
    (p : ℕ) (d : R) : (pencil R p d).map f = pencil S p (f d) := by
  simp [pencil,Polynomial.map_add,Polynomial.map_mul,map_delta]

theorem eval23 (m : ℕ) (x : ZMod 23) :
    (EulerNormalized.A (ZMod 23) m).eval x = EulerMoments.eulerAt23 m x := by
  rw [EulerNormalized.alternating (p:=23) (by decide) (by decide)]
  unfold EulerMoments.eulerAt23
  change _ = ((List.range 23).map fun j =>
    (if j%2=0 then 1 else -1 : ZMod 23) *
      (x + ((2*j+1 : ℕ) : ZMod 23))^m).sum
  rw [← List.sum_toFinset _ (List.nodup_range (n:=23))]
  simp only [List.toFinset_range]
  apply Finset.sum_congr rfl
  intro j _
  simp only [neg_one_pow_eq_ite, Nat.even_iff]
  push_cast
  ring

theorem delta23 (m : ℕ) (u : ZMod 23) :
    (delta (ZMod 23) m).eval u = EulerMoments.eulerDelta23 m u := by
  rw [delta,eval_sub,eval_C]
  exact congrArg₂ (fun x y : ZMod 23 => x-y) (eval23 m u) (eval23 m 0)

private theorem pencil23 (p : ℕ) (d u : ZMod 23) : (pencil (ZMod 23) p d).eval u =
      (EulerMoments.eulerDelta23 (2*p) u + (show Fin 23 from d)*
        EulerMoments.eulerDelta23 (2*p-2) u : Fin 23) := by
  rw [pencil, eval_add, eval_mul, eval_C]
  exact congrArg₂ (fun x y : ZMod 23 => x+d*y) (delta23 (2*p) u) (delta23 (2*p-2) u)

/-- The classical normalized polynomial itself has a nonsquare value. -/
theorem smallWitness {p : ℕ} (hp : p ∈ ([3,5,7,11] : List ℕ)) (d : ZMod 23) :
    ∃ z : ZMod 23, ¬ ∃ y : ZMod 23, y^2 = (pencil (ZMod 23) p d).eval z := by
  obtain ⟨z,_,hz⟩ := EulerMoments.exceptionalNonsquare hp (show Fin 23 from d)
  refine ⟨z,?_⟩
  rintro ⟨y,hy⟩
  apply hz
  refine ⟨y,?_⟩
  rw [pow_two] at hy
  exact hy.trans (pencil23 p d z)

/-- No integral polynomial can square to the normalized pencil in the four
exceptional degrees. -/
theorem exceptionalNotSquare {p : ℕ} (hp : p ∈ ([3,5,7,11] : List ℕ)) (d : ℤ) (S : ℤ[X]) :
    S^2 ≠ pencil ℤ p d := by
  intro he
  have h := congrArg (Polynomial.map (Int.castRingHom (ZMod 23))) he
  rw [Polynomial.map_pow,map_pencil] at h
  obtain ⟨z,hz⟩ := smallWitness hp (Int.castRingHom (ZMod 23) d)
  exact hz ⟨_,by simpa only [Polynomial.eval_pow] using congrArg (Polynomial.eval z) h⟩

#print axioms exceptionalNotSquare
end EulerSmall
