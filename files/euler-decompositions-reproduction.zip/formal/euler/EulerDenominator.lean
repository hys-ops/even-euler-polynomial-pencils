import Mathlib.NumberTheory.Padics.PadicVal.Basic
import Mathlib.Data.Nat.Factorization.Basic
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Field.ZMod
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.NormNum

/-! Degree drop and rational p-adic arithmetic in the denominator obstruction.
The passage from a rational Euler decomposition to locally normalized integral
polynomials is an external hypothesis here. -/
namespace EulerDenominator

open Polynomial
open scoped Polynomial

/-- Losing exactly two degrees forces outer degree two and one inner degree lost,
once the standard right-quadratic decomposition has been excluded. -/
theorem degree_drop {a b u v : ℕ} (ha : 2 ≤ a) (hb : 3 ≤ b)
    (hu : u ≤ a) (hv : v ≤ b) (hh : u*v + 2 = a*b) :
    a = 2 ∧ u = 2 ∧ v+1 = b := by
  have hua : u = a := by
    by_contra h
    have lt : u+1 ≤ a := by omega
    have h₁ := Nat.mul_le_mul_right b lt
    have h₂ := Nat.mul_le_mul_left u hv
    rw [Nat.add_mul, Nat.one_mul] at h₁
    omega
  subst u
  have lv : v+1 ≤ b := by
    by_contra h
    have : v = b := by omega
    subst v
    omega
  have h₃ := Nat.mul_le_mul_left a lv
  rw [Nat.mul_add, Nat.mul_one] at h₃
  have : a = 2 := by omega
  subst a
  omega

/-- The degree-drop lemma for reduction of an actual composed polynomial. -/
theorem mapped_composition {R k : Type*} [CommRing R] [IsDomain R]
    [CommRing k] [IsDomain k] (red : R →+* k) (U V : R[X])
    (hU : 2 ≤ U.natDegree) (hV : 3 ≤ V.natDegree)
    (drop : ((U.comp V).map red).natDegree + 2 = (U.comp V).natDegree) :
    U.natDegree = 2 ∧ (U.map red).natDegree = 2 ∧ (V.map red).natDegree+1 = V.natDegree := by
  rw [Polynomial.map_comp, Polynomial.natDegree_comp, Polynomial.natDegree_comp] at drop
  exact degree_drop hU hV Polynomial.natDegree_map_le Polynomial.natDegree_map_le drop

/-- The second-highest coefficient of a square from the first coefficient of
the reversed square. -/
theorem square_nextCoeff {R : Type*} [CommRing R] [IsDomain R] (V : R[X]) :
    (V^2).nextCoeff = 2 * V.leadingCoeff * V.nextCoeff := by
  rw [pow_two, ← coeff_one_reverse, reverse_mul_of_domain, mul_coeff_one,
    coeff_zero_reverse, coeff_one_reverse]
  ring

/-- The leading and next-to-leading coefficients of an actual quadratic
composition, including a nonmonic inner factor. -/
theorem quadratic_coefficients {R : Type*} [CommRing R] [IsDomain R] (U V : R[X]) (hu : U.natDegree = 2) (hv : 2 ≤ V.natDegree) :
    (U.comp V).leadingCoeff = U.leadingCoeff * V.leadingCoeff^2 ∧
    (U.comp V).nextCoeff = 2*U.leadingCoeff*V.leadingCoeff*V.nextCoeff := by
  constructor
  · rw [leadingCoeff_comp (by omega), hu]
  have shape : U.comp V = C (U.coeff 0) + C (U.coeff 1)*V + C (U.coeff 2)*V^2 := by
    rw [Polynomial.comp, eval₂_eq_sum_range' _ (n := 3) (by omega)]
    simp [Finset.sum_range_succ]
  have deg := natDegree_comp (p := U) (q := V)
  rw [hu] at deg
  let j := 2*V.natDegree-1
  have hj : V.natDegree < j := by dsimp [j]; omega
  have hl : U.coeff 2 = U.leadingCoeff := hu ▸ U.coeff_natDegree
  have sqdeg : (V^2).natDegree = 2*V.natDegree := by
    rw [natDegree_pow]
  have sq := square_nextCoeff V
  rw [nextCoeff_of_natDegree_pos (by omega), sqdeg] at sq
  rw [nextCoeff_of_natDegree_pos (by omega), deg]
  change (U.comp V).coeff j = _
  rw [shape, coeff_add, coeff_add, coeff_C_mul, coeff_C_mul]
  have h0 : (C (U.coeff 0)).coeff j = 0 :=
    coeff_eq_zero_of_natDegree_lt (by rw [natDegree_C]; omega)
  rw [h0, coeff_eq_zero_of_natDegree_lt hj, zero_add, mul_zero, zero_add, hl]
  change U.leadingCoeff*(V^2).coeff (2*V.natDegree-1) = _
  rw [sq]
  ring

/-- Leading coefficients of the normalized inner and outer factors in Q at p. -/
structure LocalData (p D b : ℕ) where
  A : ℚ
  L : ℚ
  M : ℚ
  leading : (D : ℚ) = A * L^2
  nextLeading : -(b : ℚ)*D = 2*A*L*M
  unitA : padicValRat p A = 0
  unitM : padicValRat p M = 0
  dropsL : 0 < padicValRat p L

/-- Build the prime-local data using the leading two coefficients of the
composite, with the valuations of the normalized factors given explicitly. -/
def localDataOfPolynomials {p D : ℕ} (U V : ℚ[X]) (hu : U.natDegree = 2)
    (hv : 2 ≤ V.natDegree) (hD : (U.comp V).leadingCoeff = (D : ℚ))
    (hN : (U.comp V).nextCoeff = -(V.natDegree : ℚ)*D)
    (hA : padicValRat p U.leadingCoeff = 0) (hM : padicValRat p V.nextCoeff = 0)
    (hL : 0 < padicValRat p V.leadingCoeff) : LocalData p D V.natDegree where
  A := U.leadingCoeff
  L := V.leadingCoeff
  M := V.nextCoeff
  leading := hD.symm.trans (quadratic_coefficients U V hu hv).1
  nextLeading := hN.symm.trans (quadratic_coefficients U V hu hv).2
  unitA := hA
  unitM := hM
  dropsL := hL

/-- An integer factorization with the actual degree drop modulo p supplies
all three valuation hypotheses and both coefficient equations. -/
noncomputable def localDataOfIntegralReduction {p D : ℕ} (hp : p.Prime) (U V : ℤ[X])
    (hU : 2 ≤ U.natDegree) (hV : 3 ≤ V.natDegree)
    (drop : ((U.comp V).map (Int.castRingHom (ZMod p))).natDegree + 2 = (U.comp V).natDegree)
    (lG : (U.comp V).leadingCoeff = (D : ℤ))
    (nG : (U.comp V).nextCoeff = -(V.natDegree : ℤ)*D) :
    LocalData p D V.natDegree := by
  let : Fact p.Prime := ⟨hp⟩
  let f := Int.castRingHom (ZMod p)
  obtain ⟨du,du',dv'⟩ := mapped_composition f U V hU hV drop
  have hunit (a : ℤ) (ha : (a : ZMod p) ≠ 0) : padicValRat p (a : ℚ) = 0 := by
    rw [padicValRat.of_int, padicValInt.eq_zero_of_not_dvd (fun hd =>
      ha ((ZMod.intCast_zmod_eq_zero_iff_dvd a p).2 hd))]
    simp
  have ha : f U.leadingCoeff ≠ 0 := by
    rw [← coeff_natDegree, ← coeff_map, du, ← du', coeff_natDegree, leadingCoeff_ne_zero]
    exact ne_zero_of_natDegree_gt (n := 0) (by omega)
  have hm : f V.nextCoeff ≠ 0 := by
    rw [nextCoeff_of_natDegree_pos (by omega), ← coeff_map]
    have hv' : V.natDegree-1 = (V.map f).natDegree := by omega
    rw [hv', coeff_natDegree, leadingCoeff_ne_zero]
    exact ne_zero_of_natDegree_gt (n := 0) (by omega)
  have hl : f V.leadingCoeff = 0 := by
    rw [← coeff_natDegree, ← coeff_map]
    exact coeff_eq_zero_of_natDegree_lt (by omega)
  have hL0 : V.leadingCoeff ≠ 0 := leadingCoeff_ne_zero.mpr (ne_zero_of_natDegree_gt (n := 0) (by omega))
  have hdvd : (p : ℤ) ∣ V.leadingCoeff :=
    (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).1 hl
  have hvp : padicValInt p V.leadingCoeff ≠ 0 := by
    intro he
    rcases padicValInt.eq_zero_iff.mp he with e | e | e
    · exact hp.ne_one e
    · exact hL0 e
    · exact e hdvd
  have ⟨eq1,eq2⟩ := quadratic_coefficients U V du (by omega)
  refine ⟨(U.leadingCoeff : ℚ), (V.leadingCoeff : ℚ), (V.nextCoeff : ℚ), ?_, ?_,
    hunit _ ha, hunit _ hm, ?_⟩
  · exact_mod_cast lG.symm.trans eq1
  · exact_mod_cast nG.symm.trans eq2
  · rw [padicValRat.of_int]
    omega

theorem local_obstruction {p D b : ℕ} (hp : p.Prime) (hD : D ≠ 0) (hb : b ≠ 0)
    (H : LocalData p D b) : p = 2 ∧ padicValNat 2 D = 2 ∧ b % 2 = 1 := by
  let : Fact p.Prime := ⟨hp⟩
  have hDq : (D : ℚ) ≠ 0 := by exact_mod_cast hD
  have hbq : (b : ℚ) ≠ 0 := by exact_mod_cast hb
  have hAL : H.A * H.L^2 ≠ 0 := H.leading ▸ hDq
  have hA : H.A ≠ 0 := left_ne_zero_of_mul hAL
  have hL : H.L ≠ 0 := by
    intro e
    simp [e] at hAL
  have relation : 2*H.M = -((b : ℚ)*H.L) := by
    apply mul_left_cancel₀ (mul_ne_zero hA hL)
    linear_combination - H.nextLeading - (b : ℚ) * H.leading
  have hM : H.M ≠ 0 := by
    intro e
    have hn := neg_ne_zero.mpr (mul_ne_zero hbq hL)
    apply hn
    simpa [e] using relation.symm
  have e := congrArg (padicValRat p) relation
  rw [padicValRat.mul (by norm_num : (2:ℚ) ≠ 0) hM, padicValRat.neg,
      padicValRat.mul hbq hL, H.unitM, add_zero, padicValRat.of_nat] at e
  have ha : padicValRat p (2:ℚ) = (padicValNat p 2 : ℤ) := padicValRat.of_nat
  rw [ha] at e
  have vL := H.dropsL
  have hpdvd : p ∣ 2 := by
    by_contra h
    rw [padicValNat.eq_zero_of_not_dvd h] at e
    omega
  have hp2 := (Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp hpdvd
  subst p
  rw [padicValNat_self] at e
  have hl1 : padicValRat 2 H.L = 1 := by omega
  have hb0 : padicValNat 2 b = 0 := by omega
  have hbodd : b % 2 = 1 := by
    have := (padicValNat.eq_zero_iff.mp hb0).resolve_left (by decide)
    have := this.resolve_left hb
    omega
  refine ⟨rfl, ?_, hbodd⟩
  have ed := congrArg (padicValRat 2) H.leading
  rw [padicValRat.of_nat, padicValRat.mul hA (pow_ne_zero _ hL), padicValRat.pow,
      H.unitA, hl1] at ed
  omega

/-- If every prime divisor of a nontrivial denominator has the normalized
leading-coefficient data, the denominator is exactly four and the (original)
degree 2b is 2 modulo 4. -/
theorem global_obstruction {D b : ℕ} (hD : 1 < D) (hb : b ≠ 0)
    (h : ∀ p : ℕ, p.Prime → p ∣ D → Nonempty (LocalData p D b)) :
    D = 4 ∧ (2*b)%4 = 2 := by
  have hd : D ≠ 0 := by omega
  have hc (p : ℕ) (hp : p.Prime) (hpd : p ∣ D) : p = 2 ∧ padicValNat 2 D = 2 ∧ b % 2 = 1 :=
    (h p hp hpd).elim (local_obstruction hp hd hb)
  obtain ⟨q,hq,hqd⟩ := Nat.exists_prime_and_dvd (by omega : D ≠ 1)
  obtain ⟨rfl,hv,hodd⟩ := hc q hq hqd
  refine ⟨Nat.eq_of_factorization_eq hd (by decide) (fun p => ?_), by omega⟩
  by_cases ep : p = 2
  · subst p
    rw [Nat.factorization_def _ Nat.prime_two, hv, Nat.factorization_def 4 Nat.prime_two]
    change 2 = padicValNat 2 (2^2)
    rw [padicValNat.pow, padicValNat_self]
  by_cases hp : p.Prime
  · have hnd : ¬ p ∣ D := fun hpd => ep (hc _ hp hpd).1
    have hnf : ¬ p ∣ 4 := by
      change ¬p ∣ 2^2
      exact fun hf => ep ((Nat.prime_dvd_prime_iff_eq hp Nat.prime_two).mp (hp.dvd_of_dvd_pow hf))
    rw [Nat.factorization_eq_zero_of_not_dvd hnd, Nat.factorization_eq_zero_of_not_dvd hnf]
  · rw [Nat.factorization_eq_zero_of_not_prime _ hp, Nat.factorization_eq_zero_of_not_prime _ hp]

/-- Apply the obstruction directly to a reduced, nonintegral pencil of two
monic integral polynomials of degree gap two. The upper polynomial has the
Euler next coefficient. Standard quadratic inner factors are excluded by the
explicit degree hypothesis. -/
theorem integral_pencil_obstruction (D : ℕ) (c : ℤ) (E H U V : ℤ[X])
    (hd : 1 < D) (cop : c.natAbs.Coprime D) (em : E.Monic) (hm : H.Monic)
    (gap : H.natDegree+2 = E.natDegree) (en : E.nextCoeff = -((E.natDegree/2 : ℕ) : ℤ))
    (hu : 2 ≤ U.natDegree) (hv : 3 ≤ V.natDegree)
    (comp : U.comp V = C (D : ℤ)*E + C c*H) :
    D = 4 ∧ E.natDegree % 4 = 2 := by
  have dz : (D : ℤ) ≠ 0 := by exact_mod_cast (by omega : D ≠ 0)
  have upper : (C (D : ℤ)*E).natDegree = E.natDegree := natDegree_C_mul dz
  have lower : (C c*H).natDegree ≤ H.natDegree := natDegree_C_mul_le _ _
  have dg : (U.comp V).natDegree = E.natDegree := by
    rw [comp, natDegree_add_eq_left_of_natDegree_lt (by omega), upper]
  have lead : (U.comp V).leadingCoeff = (D : ℤ) := by
    rw [leadingCoeff, dg, comp, coeff_add, coeff_C_mul, coeff_natDegree, em.leadingCoeff,
      coeff_eq_zero_of_natDegree_lt (by omega)]
    ring
  have next : (U.comp V).nextCoeff = -((E.natDegree/2 : ℕ) : ℤ)*D := by
    rw [nextCoeff_of_natDegree_pos (by omega), dg, comp, coeff_add, coeff_C_mul,
      ← nextCoeff_of_natDegree_pos (by omega), en, coeff_eq_zero_of_natDegree_lt (by omega)]
    ring
  have reddeg (p : ℕ) (pp : p.Prime) (pd : p ∣ D) :
      ((U.comp V).map (Int.castRingHom (ZMod p))).natDegree + 2 = (U.comp V).natDegree := by
    let : Fact p.Prime := ⟨pp⟩
    let f := Int.castRingHom (ZMod p)
    have fc : f c ≠ 0 := by
      intro z
      have zz := (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp z
      have gg := Nat.dvd_gcd (Int.ofNat_dvd_left.mp zz) pd
      exact pp.not_dvd_one (cop ▸ gg)
    have fd : f (D : ℤ) = 0 := by
      change ((D : ℤ) : ZMod p) = 0
      simpa using (ZMod.natCast_eq_zero_iff _ _).2 pd
    have fH : f H.leadingCoeff ≠ 0 := by simp [hm.leadingCoeff]
    rw [dg, comp]
    change ((C (D : ℤ) * E + C c * H).map f).natDegree + 2 = E.natDegree
    rw [Polynomial.map_add, Polynomial.map_mul, Polynomial.map_mul, map_C, map_C,
        fd, C_0, zero_mul, zero_add, natDegree_C_mul fc,
        natDegree_map_of_leadingCoeff_ne_zero f fH, gap]
  obtain ⟨q,hq,qd⟩ := Nat.exists_prime_and_dvd (by omega : D ≠ 1)
  let : Fact q.Prime := ⟨hq⟩
  have u2 := (mapped_composition (Int.castRingHom (ZMod q)) U V hu hv (reddeg q hq qd)).1
  have size : E.natDegree = 2*V.natDegree := by rw [← dg, natDegree_comp, u2]
  have next' : (U.comp V).nextCoeff = -(V.natDegree : ℤ)*D := by
    simpa [size] using next
  obtain ⟨d4,mod4⟩ := global_obstruction hd (by omega : V.natDegree ≠ 0)
    (fun p pp pd => ⟨localDataOfIntegralReduction pp U V hu hv (reddeg p pp pd) lead next'⟩)
  exact ⟨d4, size ▸ mod4⟩

end EulerDenominator
