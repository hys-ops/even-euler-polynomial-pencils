import EulerParity
import EulerNormalized

/-! Values of the actual normalized Euler family at the parity-selected residues. -/
namespace EulerResidue
open Finset EulerNormalized
variable {p : ℕ} [Fact p.Prime]

private theorem two_ne (h5 : 5 < p) : (2 : ZMod p) ≠ 0 := by
  intro h
  have := Nat.le_of_dvd (by decide : 0 < 2) ((ZMod.natCast_eq_zero_iff 2 p).mp h)
  omega

private theorem sumSigns (h5 : 5 < p) :
    ∑ j ∈ range p, (-1:ZMod p)^j = 1 := by
  have ho := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  have h := EulerParity.alternatingPrefix (K:=ZMod p) (fun _ => 1) 0 p (fun _ => by ring)
  simp only [pow_zero,mul_one,ho.neg_one_pow] at h
  apply mul_left_cancel₀ (two_ne h5)
  linear_combination h

private theorem sumLinear (h5 : 5 < p) :
    ∑ j ∈ range p, (-1:ZMod p)^j*(2*(j:ZMod p)+1) = 0 := by
  have ho := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  have h := EulerParity.alternatingPrefix (K:=ZMod p) (fun x => x) 1 p (fun x => by ring)
  simp only [pow_one,ho.neg_one_pow,ZMod.natCast_self,mul_zero,sub_zero] at h
  apply mul_left_cancel₀ (two_ne h5)
  linear_combination h

/-- In the prime field the high-degree summand has exactly the same differences
    as the square function. -/
theorem high_values (h5 : 5 < p) (x : ZMod p) :
    (A (ZMod p) (2*p)).eval x - (A (ZMod p) (2*p)).eval 0 = x^2 := by
  have ho := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  rw [alternating ho (two_ne h5), alternating ho (two_ne h5)]
  simp only [Nat.mul_comm 2 p, pow_mul, ZMod.pow_card, zero_add]
  rw [← sum_sub_distrib]
  calc
    _ = ∑ j ∈ range p, (x^2 * (-1:ZMod p)^j +
        (2*x) * ((-1:ZMod p)^j*(2*(j:ZMod p)+1))) := by
      apply sum_congr rfl
      intro j _
      ring
    _ = _ := by rw [sum_add_distrib, ← mul_sum, ← mul_sum, sumSigns h5, sumLinear h5]; ring

private theorem coord_zero_iff (h5 : 5 < p) {i j : ℕ} (hi : i < p) (hj : j < p) :
    EulerParity.coord p i + 2*(j:ZMod p)+1 = 0 ↔ j=i := by
  constructor
  · intro h
    dsimp [EulerParity.coord] at h
    have hc : 2*((j:ZMod p)-(i:ZMod p))=0 := by linear_combination h
    have hh := sub_eq_zero.mp ((mul_eq_zero.mp hc).resolve_left (two_ne h5))
    simpa only [ZMod.val_natCast_of_lt hi, ZMod.val_natCast_of_lt hj] using congrArg ZMod.val hh
  · rintro rfl
    simp only [EulerParity.coord]; ring

/-- The complementary exponent is the indicator of a nonzero difference in F_p.
Only the index of the designated coordinate is deleted from the alternating sum. -/
theorem lower_at_coord (h5 : 5 < p) (i : ℕ) (hi : i < p) :
    (A (ZMod p) (2*p-2)).eval (EulerParity.coord p i) = 1 - (-1:ZMod p)^i := by
  have ho := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  rw [alternating ho (two_ne h5)]
  calc
    _ = ∑ j ∈ range p, ((-1:ZMod p)^j - if j=i then (-1:ZMod p)^i else 0) := by
      apply sum_congr rfl
      intro j hj
      have h := coord_zero_iff h5 hi (mem_range.mp hj)
      by_cases he : j=i
      · have hx := h.mpr he
        rw [hx]
        simp [he, show 2*p-2 ≠ 0 from by omega]
      · have hu := ZMod.pow_card_sub_one_eq_one (mt h.mp he)
        rw [show 2*p-2=(p-1)*2 from by omega, pow_mul, hu]
        simp [he]
    _ = _ := by simp [sum_sub_distrib, sumSigns h5, hi]

private theorem mid_coord (h5 : 5 < p) : EulerParity.coord p (p/2) = 0 := by
  obtain ⟨t,ht⟩ := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  have hm : 2*(p/2)+1=p := by omega
  have hx := congrArg (fun j : ℕ => (j:ZMod p)) hm
  simp only [Nat.cast_add,Nat.cast_mul,Nat.cast_two,Nat.cast_one,ZMod.natCast_self] at hx
  simpa [EulerParity.coord] using congrArg Neg.neg hx

private theorem sign_mod (j : ℕ) :
    (-1:ZMod p)^j = (if j%2=0 then 1 else -1) := by
  rcases Nat.even_or_odd j with he|ho
  · simp [he.neg_one_pow, Nat.even_iff.mp he]
  · obtain ⟨t,ht⟩ := ho
    have hh : j%2 ≠ 0 := by omega
    simp only [hh, ↓reduceIte]
    exact (show Odd j from ⟨t,ht⟩).neg_one_pow

/-- The lower-degree difference contributes a single nonzero correction on B. -/
theorem lower_on_B (h5 : 5 < p) {z : ZMod p} (hz : z ∈ EulerParity.B p) :
    (A (ZMod p) (2*p-2)).eval z - (A (ZMod p) (2*p-2)).eval 0 =
      2*(if p%4=1 then 1 else -1 : ZMod p) := by
  obtain ⟨i,hi,rfl⟩ := mem_image.mp hz
  obtain ⟨him,his⟩ := mem_filter.mp hi
  have hi' := mem_range.mp him
  rw [lower_at_coord h5 i hi', ← mid_coord h5,
    lower_at_coord h5 (p/2) (by omega), sign_mod, sign_mod]
  obtain ⟨t,ht⟩ := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  by_cases hp : p%4=1
  · simp [hp, show (p/2)%2=0 from by omega, show i%2≠0 from by omega]
    ring
  · simp [hp, show (p/2)%2≠0 from by omega, show i%2=0 from by omega]
    ring

theorem on_B (h5 : 5 < p) (d : ZMod p) {z : ZMod p} (hz : z ∈ EulerParity.B p) :
    ((A (ZMod p) (2*p)).eval z - (A (ZMod p) (2*p)).eval 0) +
      d * ((A (ZMod p) (2*p-2)).eval z - (A (ZMod p) (2*p-2)).eval 0) =
      z^2 + 2*(if p%4=1 then 1 else -1 : ZMod p)*d := by
  rw [high_values h5, lower_on_B h5 hz]
  ring

#print axioms on_B
end EulerResidue
