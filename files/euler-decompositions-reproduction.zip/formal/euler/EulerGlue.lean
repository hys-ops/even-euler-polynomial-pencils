import EulerParity
import EulerHalf
import EulerMoments

/-! Combines the hyperbola parametrization, the computed moments over units,
and the prime exclusions. All sums below range over elements of the stated
finite sets in the prime field. -/
namespace EulerGlue

theorem exceptionsOfSymmetricMoments {p : ℕ} [Fact p.Prime]
    (h5 : 5 < p) (a : ZMod p) (ha : a ≠ 0) (B : Finset (ZMod p))
    (hc : p ≤ 2*B.card+1) (hs : ∀ z, z ∈ B ↔ -z ∈ B)
    (hb2 : 2*(∑ z ∈ B, z^2) = (if p%4=1 then 1 else -1 : ZMod p))
    (hb4 : 2*(∑ z ∈ B, z^4) = -5*(if p%4=1 then 1 else -1 : ZMod p))
    (hsub : B ⊆ EulerHalf.sqValues a) : p=7 ∨ p=11 := by
  classical
  have two : (2 : ZMod p) ≠ 0 := by
    intro hh
    have hd := (ZMod.natCast_eq_zero_iff 2 p).mp hh
    have := Nat.le_of_dvd (by decide : 0<2) hd
    omega
  have hz : ∀ z ∈ EulerHalf.zeroValues a, z^2 = -a := by
    intro z hz
    exact eq_neg_iff_add_eq_zero.mpr ((Finset.mem_filter.mp hz).2)
  have sz2 : (∑ z ∈ EulerHalf.zeroValues a, z^2) =
      ((EulerHalf.zeroValues a).card : ZMod p)*(-a) := by
    calc
      _ = ∑ _z ∈ EulerHalf.zeroValues a, -a := Finset.sum_congr rfl hz
      _ = _ := by simp [nsmul_eq_mul]
  have sz4 : (∑ z ∈ EulerHalf.zeroValues a, z^4) =
      ((EulerHalf.zeroValues a).card : ZMod p)*a^2 := by
    calc
      _ = ∑ _z ∈ EulerHalf.zeroValues a, a^2 := by
        apply Finset.sum_congr rfl
        intro z h
        rw [show (4:ℕ) = 2*2 by decide, pow_mul, hz z h, neg_sq]
      _ = _ := by simp [nsmul_eq_mul]
  have hcnt : Fintype.card (ZMod p) ≤ 2*B.card+1 := by rwa [ZMod.card]
  have w2 := EulerHalf.lowerHalfMoments (fun z : ZMod p => z^2) (by simp) a ha two B hcnt hs hsub
  have w4 := EulerHalf.lowerHalfMoments (fun z : ZMod p => z^4) (by simp) a ha two B hcnt hs hsub
  have ⟨u2,u4⟩ := EulerMoments.coordinateHyperbolaMoments h5 a
  change (∑ w : (ZMod p)ˣ, (((w:ZMod p)-a/(w:ZMod p))/2)^2) +
      ∑ z ∈ EulerHalf.zeroValues a, z^2 = 2 • (∑ z ∈ B, z^2) at w2
  change (∑ w : (ZMod p)ˣ, (((w:ZMod p)-a/(w:ZMod p))/2)^4) +
      ∑ z ∈ EulerHalf.zeroValues a, z^4 = 2 • (∑ z ∈ B, z^4) at w4
  rw [u2,sz2,nsmul_eq_mul] at w2
  rw [u4,sz4,nsmul_eq_mul] at w4
  push_cast at w2 w4
  rw [hb2] at w2
  rw [hb4] at w4
  apply EulerMoments.momentExceptions (Fact.out : p.Prime) h5 a
    ((EulerHalf.zeroValues a).card : ZMod p)
  · rcases EulerHalf.cardZeroValues a ha two with h | h <;> simp [h]
  · field_simp [two] at w2
    linear_combination -w2
  · field_simp [two] at w4
    apply mul_left_cancel₀ two
    linear_combination -w4

/-- For all primes greater than 5 except 7 and 11, every nonzero parameter
has a nonsquare on the explicit arithmetic half-progression. -/
theorem nonsquareOnProgression {p : ℕ} [Fact p.Prime] (h5 : 5 < p)
    (h7 : p ≠ 7) (h11 : p ≠ 11) (a : ZMod p) (ha : a ≠ 0) :
    ∃ z ∈ EulerParity.B p, ¬ ∃ y : ZMod p, y^2 = z^2+a := by
  classical
  by_contra! h
  have hs : EulerParity.B p ⊆ EulerHalf.sqValues a := by
    intro z hz
    simpa [EulerHalf.sqValues] using h z hz
  obtain ⟨m2,m4⟩ := EulerParity.secondFourth h5
  have hcard : p ≤ 2*(EulerParity.B p).card+1 := by
    simpa only [ZMod.card] using EulerParity.card_lower h5
  rcases exceptionsOfSymmetricMoments h5 a ha (EulerParity.B p) hcard
      (EulerParity.symmetric h5) m2 m4 hs with h | h
  · exact h7 h
  · exact h11 h

#print axioms nonsquareOnProgression
#print axioms exceptionsOfSymmetricMoments
end EulerGlue
