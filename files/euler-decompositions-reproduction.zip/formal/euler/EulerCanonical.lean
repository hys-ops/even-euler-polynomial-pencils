import EulerClassification
import EulerGeneralOriginal

/-! The three proven ranges of the decomposition conjecture, stated for a
particular sequence of Euler polynomials with no polynomial-model hypotheses. -/
namespace EulerCanonical
open Polynomial EulerEvenIntegral
noncomputable section
variable (K : Type*) [Field K] [CharZero K]

/-- The degree-2m member of the pencil in the original x coordinate. -/
def combination (m : ℕ) (c : ℚ) : K[X] :=
  evenEuler K m + C (c : K) * evenEuler K (m-1)

/-- A fixed quadratic inner and a unique outer; every nonlinear composition
arises by changing the intermediate coordinate by an invertible affine map. -/
def StandardOnly (H : K[X]) : Prop :=
  ∃! G : K[X], G.comp (X^2-X) = H ∧
    ∀ U V : K[X], U.comp V = H → 2 ≤ U.natDegree → 2 ≤ V.natDegree →
      ∃ a b : K, a ≠ 0 ∧ V=(C a*X+C b).comp (X^2-X) ∧ G=U.comp (C a*X+C b)

private theorem standard_of_inners (m : ℕ) (c : ℚ)
    (hi : ∀ U V : K[X], U.comp V=combination K m c → 2≤U.natDegree → 2≤V.natDegree →
      ∃ a b : K, a≠0 ∧ V=C a*(X^2-X)+C b) :
    StandardOnly K (combination K m c) := by
  let T : K[X] := X^2-X
  have hT : 0 < T.natDegree := by
    unfold T
    rw [natDegree_sub_eq_left_of_natDegree_lt] <;> simp
  obtain ⟨G,hG⟩ := EulerClassification.standard_exists (combination K m c) (by
    intro x
    simp only [combination,eval_add,eval_mul,eval_C,evenEuler_reflect])
  refine ⟨G,⟨hG,?_⟩,?_⟩
  · intro U V hcomp hU hV
    obtain ⟨a,b,ha,h⟩ := hi U V hcomp hU hV
    have h' : V=(C a*X+C b).comp T := by simpa only [T,add_comp,mul_comp,C_comp,X_comp] using h
    refine ⟨a,b,ha,h',EulerClassification.comp_cancel _ _ T hT ?_⟩
    rw [comp_assoc,← h',hcomp]
    exact hG
  · intro G' hG'
    exact EulerClassification.comp_cancel _ _ T hT (hG'.1.trans hG.symm)

theorem twice_odd_prime (p : ℕ) (hp : p.Prime) (hodd : 2<p) (c : ℚ) :
    StandardOnly K (combination K p c) := by
  letI : Fact p.Prime := ⟨hp⟩
  apply EulerClassification.eulerTwicePrime_complete hodd c _ _ (shift p)
  simpa only [show 2*(p-1)=2*p-2 by omega] using (shift (R:=K) (p-1))

theorem degree_eight (c : ℚ) : StandardOnly K (combination K 4 c) := by
  apply standard_of_inners
  intro U V hcomp hU hV
  exact EulerEight.eulerEight_from_defining_identities c _ _ U V (shift (R:=K) 3)
    (shift (R:=K) 4) hcomp hU hV

theorem denominator (m : ℕ) (hm : 1≤m) (c : ℚ) (hd : 1<c.den)
    (h : ¬ (c.den=4 ∧ 2*m%4=2)) : StandardOnly K (combination K m c) := by
  apply standard_of_inners
  intro U V hcomp hU hV
  apply (EulerGeneralOriginal.uniqueness_unless_quarter m c.den c.num _ _ U V hm hd c.reduced
    (shift (R:=K) m) (shift (R:=K) (m-1)) hU hV ?_).resolve_right h
  simpa only [combination, Rat.cast_def] using hcomp

end
end EulerCanonical
