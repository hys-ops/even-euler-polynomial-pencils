import EulerEvenIntegral
import RationalCompositionDescent

namespace EulerGeneralOriginal
open Polynomial EulerEvenIntegral
open scoped BigOperators

/-- The denominator obstruction for every nontrivial characteristic-zero
decomposition, in the ordinary Euler coordinates x and x²-x. -/
theorem uniqueness_unless_quarter {K : Type*} [Field K] [CharZero K]
    (m D : ℕ) (c : ℤ) (E H U V : K[X])
    (hm : 1 ≤ m) (hd : 1 < D) (cop : c.natAbs.Coprime D)
    (he : ∀ x : K, E.eval (x+1)+E.eval x = 2*x^(2*m))
    (hh : ∀ x : K, H.eval (x+1)+H.eval x = 2*x^(2*(m-1)))
    (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree)
    (hcomp : U.comp V = E+C ((c:K)/(D:K))*H) :
    (∃ a b : K, a ≠ 0 ∧ V=C a*(X^2-X)+C b) ∨ (D=4 ∧ 2*m%4=2) := by
  have hi : E=evenEuler K m := (integral_model m E he).trans (map_evenEuler _ _)
  have hj : H=evenEuler K (m-1) := (integral_model _ H hh).trans (map_evenEuler _ _)
  by_cases h2 : V.natDegree=2
  · apply Or.inl
    apply quadratic_inner U V (by omega) h2
    intro x
    simp only [hcomp,hi,hj,eval_add,eval_mul,eval_C,evenEuler_reflect]
  · right
    let F : ℚ[X] := evenEuler ℚ m + C ((c:ℚ)/(D:ℚ)) * evenEuler ℚ (m-1)
    have hmap : F.map (algebraMap ℚ K)=U.comp V := by
      rw [hcomp,hi,hj]
      simp [F,Polynomial.map_add,Polynomial.map_mul, map_evenEuler]
    obtain ⟨A,B,e,ad,bd⟩ := RationalCompositionDescent.descend F U V (by omega) (by omega) hmap
    exact ordinary_denominator m D c (evenEuler ℚ m) (evenEuler ℚ (m-1)) A B hm hd cop
      (shift m) (shift (m-1)) (by omega) (by omega) e

#print axioms uniqueness_unless_quarter
end EulerGeneralOriginal
