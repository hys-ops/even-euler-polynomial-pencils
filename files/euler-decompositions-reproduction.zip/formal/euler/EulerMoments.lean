import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Nat.Prime.Basic
import Mathlib.Tactic.LinearCombination
import Mathlib.FieldTheory.Finite.Basic
import Mathlib.Tactic.FieldSimp

/-!
# Local arithmetic for the even Euler-polynomial decomposition problem

We compute the two moments over units in the prime field and derive the
exceptional primes from the resulting denominator-cleared equations. The last theorem checks the exceptional
indices by computing the defining alternating sums in characteristic 23.
-/

namespace EulerMoments


/-- Exact second and fourth moments of the numerator in the hyperbola
parametrization, summing over all nonzero elements of the prime field. -/
theorem unitHyperbolaMoments {p : ℕ} [Fact p.Prime] (h5 : 5 < p) (a : ZMod p) :
    (∑ w : (ZMod p)ˣ, ((w : ZMod p) - a / (w : ZMod p))^2) = 2*a ∧
    (∑ w : (ZMod p)ˣ, ((w : ZMod p) - a / (w : ZMod p))^4) = -6*a^2 := by
  classical
  have vpow (k : ℕ) (hk : 0 < k) (hk' : k ≤ 4) :
      (∑ w : (ZMod p)ˣ, (w : ZMod p)^k) = 0 := by
    rw [FiniteField.sum_pow_units, ZMod.card]
    simp only [ite_eq_right_iff, neg_eq_zero, one_ne_zero]
    exact fun hd => by have := Nat.le_of_dvd hk hd; omega
  have ipow (k : ℕ) (hk : 0 < k) (hk' : k ≤ 4) :
      (∑ w : (ZMod p)ˣ, (w : ZMod p)⁻¹^k) = 0 := by
    calc
      _ = ∑ w : (ZMod p)ˣ, ((w⁻¹ : (ZMod p)ˣ) : ZMod p)^k := by
        simp only [Units.val_inv_eq_inv_val]
      _ = ∑ w : (ZMod p)ˣ, (w : ZMod p)^k :=
        Equiv.sum_comp (Equiv.inv ((ZMod p)ˣ)) (fun w => (w : ZMod p)^k)
      _ = 0 := vpow k hk hk'
  have csum (b : ZMod p) : (∑ _w : (ZMod p)ˣ, b) = -b := by
    simp only [Finset.sum_const, Finset.card_univ, Fintype.card_units, ZMod.card, nsmul_eq_mul]
    rw [Nat.cast_sub (by omega : 1 ≤ p), CharP.cast_eq_zero (ZMod p) p]
    simp
  have hv2 := vpow 2 (by decide) (by decide)
  have hv4 := vpow 4 (by decide) (by decide)
  have hi2 := ipow 2 (by decide) (by decide)
  have hi4 := ipow 4 (by decide) (by decide)
  constructor
  · calc
      _ = ∑ w : (ZMod p)ˣ, ((w : ZMod p)^2 - 2*a + a^2*((w : ZMod p)⁻¹)^2) := by
        apply Finset.sum_congr rfl
        intro w _
        field_simp [w.ne_zero]
        ring
      _ = _ := by
        simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum,
          hv2, hi2, csum]
        ring
  · calc
      _ = ∑ w : (ZMod p)ˣ, ((w : ZMod p)^4 - (4*a)*(w : ZMod p)^2 + 6*a^2 -
            (4*a^3)*((w : ZMod p)⁻¹)^2 + a^4*((w : ZMod p)⁻¹)^4) := by
        apply Finset.sum_congr rfl
        intro w _
        field_simp [w.ne_zero]
        ring
      _ = _ := by
        simp only [Finset.sum_add_distrib, Finset.sum_sub_distrib, ← Finset.mul_sum,
          hv2, hv4, hi2, hi4, csum]
        ring

/-- Moments in the actual coordinate of the hyperbola parametrization. -/
theorem coordinateHyperbolaMoments {p : ℕ} [Fact p.Prime] (h5 : 5 < p) (a : ZMod p) :
    (∑ w : (ZMod p)ˣ, (((w : ZMod p) - a / (w : ZMod p))/2)^2) = 2*a/2^2 ∧
    (∑ w : (ZMod p)ˣ, (((w : ZMod p) - a / (w : ZMod p))/2)^4) = -6*a^2/2^4 := by
  obtain ⟨h2,h4⟩ := unitHyperbolaMoments h5 a
  simp only [div_pow]
  simp only [div_eq_mul_inv, ← Finset.sum_mul] at *
  exact ⟨congrArg (· * ((2 : ZMod p)^2)⁻¹) h2, congrArg (· * ((2 : ZMod p)^4)⁻¹) h4⟩

private theorem stripFour {p k : ℕ} (hp : p.Prime) (h5 : 5 < p)
    (h : ((4*k : ℕ) : ZMod p) = 0) : p ∣ k := by
  have hd := (ZMod.natCast_eq_zero_iff (4*k) p).mp h
  exact (hp.dvd_mul.mp hd).resolve_left (fun w => by
    have := Nat.le_of_dvd (by decide : 0 < 4) w
    omega)

/-- The two necessary moments permit only the primes 7 and 11 above 5. -/
theorem momentExceptions {p : ℕ} (hp : p.Prime) (h5 : 5 < p)
    (a z : ZMod p) (hz : z = 0 ∨ z = 2)
    (h2 : 2 * (if p % 4 = 1 then 1 else -1 : ZMod p) = (1 - 2*z)*a)
    (h4 : -40 * (if p % 4 = 1 then 1 else -1 : ZMod p) = (8*z - 3)*a^2) :
    p = 7 ∨ p = 11 := by
  by_cases hs : p % 4 = 1
  · simp only [hs, ↓reduceIte] at h2 h4
    rcases hz with rfl | rfl
    · have h : (28 : ZMod p) = 0 := by linear_combination -h4 - 3*(a+2)*h2
      have hd : p ∣ 7 := stripFour hp h5 h
      have pe := (Nat.prime_dvd_prime_iff_eq hp (by decide : Nat.Prime 7)).mp hd
      omega
    · have h : (412 : ZMod p) = 0 := by linear_combination -9*h4 - 13*(3*a-2)*h2
      have hd : p ∣ 103 := stripFour hp h5 h
      have pe := (Nat.prime_dvd_prime_iff_eq hp (by decide : Nat.Prime 103)).mp hd
      omega
  · simp only [hs, ↓reduceIte] at h2 h4
    rcases hz with rfl | rfl
    · have h : (52 : ZMod p) = 0 := by linear_combination h4 + 3*(a-2)*h2
      have hd : p ∣ 13 := stripFour hp h5 h
      have pe := (Nat.prime_dvd_prime_iff_eq hp (by decide : Nat.Prime 13)).mp hd
      omega
    · have h : (308 : ZMod p) = 0 := by linear_combination 9*h4 + 13*(3*a+2)*h2
      have hd : p ∣ 77 := stripFour hp h5 h
      rcases hp.dvd_mul.mp (show p ∣ 7*11 from hd) with h7 | h11
      · exact Or.inl ((Nat.prime_dvd_prime_iff_eq hp (by decide : Nat.Prime 7)).mp h7)
      · exact Or.inr ((Nat.prime_dvd_prime_iff_eq hp (by decide : Nat.Prime 11)).mp h11)

/-- Normalized Euler polynomial in characteristic 23, evaluated using the
finite alternating sum from its difference equation. -/
def eulerAt23 (m : ℕ) (x : Fin 23) : Fin 23 :=
  ((List.range 23).map fun j =>
    (if j % 2 = 0 then 1 else -1 : Fin 23) * (x + Fin.ofNat 23 (2*j+1)) ^ m).sum

def eulerDelta23 (m : ℕ) (x : Fin 23) : Fin 23 := eulerAt23 m x - eulerAt23 m 0

/-- Square testing includes zero. -/
def square23 (x : Fin 23) : Bool := (List.finRange 23).any fun y => y*y == x

def fourPoints : List (Fin 23) := [1,2,3,11]

def admissible23 (m : ℕ) (d : Fin 23) : Bool :=
  fourPoints.all fun z => square23 (eulerDelta23 (2*m) z + d * eulerDelta23 (2*m-2) z)

set_option maxRecDepth 500000 in
set_option maxHeartbeats 10000000 in
/-- No coefficient in characteristic 23 passes all four square tests for any
of the four exceptional prime indices. The computation is kernel-reduced. -/
theorem fourPointExceptions : ∀ p ∈ ([3,5,7,11] : List ℕ), ∀ d : Fin 23,
    admissible23 p d = false := by
  intro p hp
  simp only [List.mem_cons, List.not_mem_nil, or_false] at hp
  rcases hp with rfl | rfl | rfl | rfl <;> decide

/-- Ordinary existential formulation of the finite certificate: every
coefficient has a witness point whose Euler-pencil value is a nonsquare. -/
theorem exceptionalNonsquare {p : ℕ} (hp : p ∈ ([3,5,7,11] : List ℕ)) (d : Fin 23) :
    ∃ z ∈ fourPoints, ¬ ∃ y : Fin 23, y*y =
      eulerDelta23 (2*p) z + d*eulerDelta23 (2*p-2) z := by
  by_contra! h
  have yes : admissible23 p d = true := by
    apply List.all_eq_true.mpr
    intro x hx
    obtain ⟨y,hy⟩ := h x hx
    apply List.any_eq_true.mpr
    exact ⟨y,List.mem_finRange _, by simpa using hy⟩
  rw [fourPointExceptions p hp d] at yes
  contradiction

#print axioms exceptionalNonsquare
#print axioms coordinateHyperbolaMoments
#print axioms momentExceptions
#print axioms fourPointExceptions

end EulerMoments
