import Mathlib.Data.Nat.Prime.Basic
import EulerDescent
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Algebra.CharZero.Infinite
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Linarith

/-! Classification of competing decompositions of any even monic
degree-2p polynomial in characteristic zero. -/
namespace EulerDecomposition
open Polynomial
noncomputable section
variable {K : Type*} [Field K] [CharZero K]

omit [CharZero K] in
private theorem quadratic_eval (Q : K[X]) (hq : Q.natDegree=2) (x : K) :
    Q.eval x = Q.coeff 0 + Q.coeff 1*x + Q.coeff 2*x^2 := by
  rw [eval_eq_sum_range' (n:=3) (by omega)]
  simp [Finset.sum_range_succ]

omit [CharZero K] in
private theorem leading_ne (Q : K[X]) (h : 0 < Q.natDegree) :
    Q.leadingCoeff ≠ 0 := by
  apply leadingCoeff_ne_zero.mpr
  intro hc
  simp [hc] at h

/-- A nonconstant polynomial over a characteristic-zero field cannot have
a nonzero additive period. -/
theorem zero_period (H : K[X]) (hd : 0 < H.natDegree) (t : K)
    (hper : ∀ x : K, H.eval (x+t)=H.eval x) : t=0 := by
  by_contra ht
  have hi : Function.Injective (fun n : ℕ => (n:K)*t) := by
    intro n m hm
    exact_mod_cast mul_right_cancel₀ ht hm
  have he : ∀ n : ℕ, H.eval ((n:K)*t)=H.eval 0 := by
    intro n
    induction n with
    | zero => simp
    | succ n ih => simpa [Nat.cast_succ, add_mul] using (hper ((n:K)*t)).trans ih
  have hc : H = C (H.eval 0) := by
    apply H.eq_of_infinite_eval_eq
    refine (Set.infinite_range_of_injective hi).mono ?_
    rintro _ ⟨n,rfl⟩
    simpa using he n
  have hc' := congrArg natDegree hc
  simp at hc'
  omega

/-- The two reflection axes of a quadratic factor and of the composite
differ by an additive period; therefore the quadratic factor is centered. -/
theorem centered_inner (H U V : K[X]) (h : U.comp V=H) (hd : 0 < H.natDegree)
    (heven : H.comp (-X) = H) (hv : V.natDegree=2) :
    ∃ a b : K, a ≠ 0 ∧ V = C a * X^2 + C b := by
  let a := V.coeff 2
  let b := V.coeff 1
  let t := b/a
  have ha : a ≠ 0 := by
    dsimp [a]; rw [← hv, coeff_natDegree]; exact leading_ne V (by omega)
  have ht : t*a=b := by dsimp [t]; field_simp
  have hper : ∀ x : K, H.eval (x+t)=H.eval x := by
    intro x
    have href := congrArg (fun P : K[X] => P.eval (x+t)) heven
    simp only [eval_comp,eval_neg,eval_X] at href
    rw [← href, ← h, eval_comp,eval_comp]
    congr 1
    rw [quadratic_eval V hv,quadratic_eval V hv]
    change V.coeff 0+b*(-(x+t))+a*(-(x+t))^2 = V.coeff 0+b*x+a*x^2
    linear_combination (2*x+t)*ht
  have ht0 := zero_period H hd t hper
  have hb : b=0 := by rw [← ht, ht0, zero_mul]
  refine ⟨a,V.coeff 0,ha,Polynomial.funext (fun x => ?_)⟩
  simp only [quadratic_eval V hv,eval_add,eval_mul,eval_C,eval_pow,eval_X]
  change V.coeff 0+b*x+a*x^2 = a*x^2 + V.coeff 0
  rw [hb]; ring

/-- Completing the square in any characteristic-zero field produces a monic
odd square root after subtracting the constant value of the composite. -/
theorem odd_square_of_outer_two (H U V : K[X]) (h : U.comp V=H)
    (hmon : H.Monic) (heven : H.comp (-X)=H) (hu : U.natDegree=2)
    (hv : Odd V.natDegree) :
    ∃ S : K[X], S.Monic ∧ S.natDegree=V.natDegree ∧ S.comp (-X) = -S ∧
      S^2=H - C (H.eval 0) := by
  let a := U.coeff 2
  let b := U.coeff 1
  let l := V.leadingCoeff
  let k := b/(2*a)
  let S := C l⁻¹ * (V+C k)
  have hvpos : 0 < V.natDegree := by obtain ⟨e,he⟩ := hv; omega
  have hl : l ≠ 0 := leading_ne V hvpos
  have ha : a ≠ 0 := by
    dsimp [a]; rw [← hu,coeff_natDegree]; exact leading_ne U (by omega)
  have htop : a*l^2 = 1 := by
    have e : (U.comp V).leadingCoeff=1 := by rw [h]; exact hmon
    rw [leadingCoeff_comp (by omega),hu] at e
    simpa [a,l,← hu,coeff_natDegree] using e
  have hSdeg : S.natDegree = V.natDegree := by simp [S,natDegree_C_mul (inv_ne_zero hl)]
  have hSmon : S.Monic := by
    rw [Monic.def]
    simp only [S,leadingCoeff_mul,leadingCoeff_C]
    rw [leadingCoeff_add_of_degree_lt' (degree_C_le.trans_lt (natDegree_pos_iff_degree_pos.mp hvpos))]
    exact inv_mul_cancel₀ hl
  have hsq : S^2=H + C (l⁻¹^2*k^2 - U.coeff 0) := by
    apply Polynomial.funext
    intro x
    rw [← h, eval_add,eval_comp,quadratic_eval U hu]
    simp only [S,eval_pow,eval_mul,eval_add,eval_C]
    change (l⁻¹*(V.eval x+k))^2 = U.coeff 0+b*V.eval x+a*(V.eval x)^2+
      (l⁻¹ ^ 2 * k ^ 2 - U.coeff 0)
    have hla : l⁻¹^2 = a := by
      rw [inv_pow, inv_eq_iff_eq_inv]
      apply eq_inv_of_mul_eq_one_left
      simpa [mul_comm] using htop
    have hk : 2*a*k = b := by dsimp [k]; field_simp
    rw [mul_pow,hla]
    linear_combination (V.eval x)*hk
  have href : (S.comp (-X))^2 = S^2 := by
    calc
      _ = (S^2).comp (-X) := (pow_comp _ _ _).symm
      _ = _ := by rw [hsq, add_comp,heven,C_comp]
  have hodd : S.comp (-X) = -S := by
    apply (sq_eq_sq_iff_eq_or_eq_neg.mp href).resolve_left
    intro hh
    have e := congrArg leadingCoeff hh
    rw [comp_neg_X_leadingCoeff_eq,hSdeg,hv.neg_one_pow,hSmon.leadingCoeff,mul_one] at e
    norm_num at e
  have h0 := congrArg (fun P : K[X] => P.eval 0) hodd
  simp only [eval_comp,eval_neg,eval_X,neg_zero] at h0
  have hS0 : S.eval 0=0 := by linear_combination h0/2
  have hconst := congrArg (fun P : K[X] => P.eval 0) hsq
  simp only [eval_pow,eval_add,eval_C,hS0,zero_pow,ne_eq,OfNat.ofNat_ne_zero,not_false_eq_true] at hconst
  refine ⟨S,hSmon,hSdeg,hodd,?_⟩
  rw [hsq]
  have hC : l⁻¹^2*k^2 - U.coeff 0 = -H.eval 0 := by linear_combination -hconst
  rw [hC,C_neg,sub_eq_add_neg]

theorem degree_pair {p u v : ℕ} (hp : p.Prime) (hu : 2 ≤ u) (hv : 2 ≤ v)
    (he : u*v=2*p) : (u=2 ∧ v=p) ∨ (u=p ∧ v=2) := by
  have hd : p ∣ u*v := by rw [he]; exact dvd_mul_left _ _
  rcases hp.dvd_mul.mp hd with hd | hd
  · have hle := Nat.le_of_dvd (by omega : 0<u) hd
    right
    have h := Nat.mul_le_mul_right v hle
    have kv : v ≤ 2 := by nlinarith [hp.pos]
    have hv2 : v=2 := by omega
    rw [hv2] at he
    exact ⟨by omega,hv2⟩
  · have hle := Nat.le_of_dvd (by omega : 0<v) hd
    left
    have h := Nat.mul_le_mul_left u hle
    have ku : u ≤ 2 := by nlinarith [hp.pos]
    have hu2 : u=2 := by omega
    rw [hu2] at he
    exact ⟨hu2,by omega⟩

/-- A nonstandard splitting of an even monic degree-2p polynomial gives an
actual monic odd square root, over the coefficient field of the splitting. -/
theorem centered_or_square {p : ℕ} (hp : p.Prime) (hp2 : p ≠ 2)
    (H U V : K[X]) (h : U.comp V=H) (hmon : H.Monic) (hd : H.natDegree=2*p)
    (heven : H.comp (-X)=H) (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree) :
    (∃ a b : K, a ≠ 0 ∧ V=C a*X^2+C b) ∨
    (∃ S : K[X], S.Monic ∧ S.natDegree=p ∧ S.comp (-X) = -S ∧ S^2=H - C (H.eval 0)) := by
  have he := congrArg natDegree h
  rw [natDegree_comp,hd] at he
  rcases degree_pair hp hu hv he with ⟨hu2,hvp⟩ | ⟨_,hv2⟩
  · right
    rw [← hvp]
    apply odd_square_of_outer_two H U V h hmon heven hu2
    rw [hvp]; exact hp.odd_of_ne_two hp2
  · left
    exact centered_inner H U V h (by rw [hd]; have := hp.pos; omega) heven hv2

/-- Over an arbitrary characteristic-zero extension, failure of the standard
inner shape forces an odd monic square root over the original rational field. -/
theorem centered_or_rational_square {p : ℕ} (hp : p.Prime) (hp2 : p ≠ 2)
    (H : ℚ[X]) (U V : K[X]) (h : U.comp V=H.map (algebraMap ℚ K))
    (hmon : H.Monic) (hd : H.natDegree=2*p)
    (heven : H.comp (-X)=H) (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree) :
    (∃ a b : K, a ≠ 0 ∧ V=C a*X^2+C b) ∨
    (∃ R : ℚ[X], R.Monic ∧ R.natDegree=p ∧ R.comp (-X) = -R ∧
      R^2=H - C (H.eval 0)) := by
  let i := algebraMap ℚ K
  have hinj : Function.Injective i := i.injective
  have hdeg : (H.map i).natDegree=2*p := (natDegree_map_eq_of_injective hinj H).trans hd
  have hpar : (H.map i).comp (-X) = H.map i := by
    simpa only [Polynomial.map_comp,Polynomial.map_neg,Polynomial.map_X] using congrArg (Polynomial.map i) heven
  rcases centered_or_square hp hp2 (H.map i) U V h (hmon.map i) hdeg hpar hu hv with hstd | ⟨S,hS,hsd,hso,hsq⟩
  · exact Or.inl hstd
  · right
    have heval : (H.map i).eval 0=i (H.eval 0) := by simp
    have heq : S^2=(H - C (H.eval 0)).map i := by
      rw [hsq, Polynomial.map_sub,Polynomial.map_C,heval]
    obtain ⟨R,hR,hmap,hr2⟩ := EulerDescent.monic_square_descends_rat S _ hS heq
    change R.map i = S at hmap
    refine ⟨R,hR,?_,?_,hr2⟩
    · rw [← natDegree_map_eq_of_injective hinj R, hmap, hsd]
    · apply Polynomial.map_injective i hinj
      simpa only [Polynomial.map_comp,Polynomial.map_neg,Polynomial.map_X,hmap] using hso

#print axioms centered_or_square
#print axioms centered_or_rational_square
end
end EulerDecomposition
