import EulerSmall
import EulerGlue
import EulerResidue
import EulerIdentification
import EulerDescent

/-! The local obstructions for the centered pencil with integral coefficient. -/
namespace EulerIntegral
open Polynomial EulerSmall

theorem unitNotSquare {p : ℕ} [Fact p.Prime] (h5 : 5 < p)
    (h7 : p ≠ 7) (h11 : p ≠ 11) (d : ZMod p) (hd : d ≠ 0) (S : (ZMod p)[X]) :
    S^2 ≠ pencil (ZMod p) p d := by
  intro he
  have h2 : (2 : ZMod p) ≠ 0 := by
    intro hh
    have hd := (ZMod.natCast_eq_zero_iff 2 p).mp hh
    have := Nat.le_of_dvd (by decide : 0<2) hd
    omega
  let e : ZMod p := if p%4=1 then 1 else -1
  have he' : e ≠ 0 := by dsimp [e]; split <;> simp
  obtain ⟨z,hz,hn⟩ := EulerGlue.nonsquareOnProgression h5 h7 h11
    (2*e*d) (mul_ne_zero (mul_ne_zero h2 he') hd)
  apply hn
  refine ⟨S.eval z,?_⟩
  have hh := congrArg (Polynomial.eval z) he
  simp only [eval_pow,pencil,delta,eval_add,eval_mul,eval_sub,eval_C] at hh
  exact hh.trans (EulerResidue.on_B h5 d hz)

theorem unitIntegralNotSquare {p : ℕ} [Fact p.Prime] (h5 : 5 < p)
    (h7 : p ≠ 7) (h11 : p ≠ 11) (d : ℤ) (hd : ¬ (p:ℤ) ∣ d) (S : ℤ[X]) :
    S^2 ≠ pencil ℤ p d := by
  intro he
  let f := Int.castRingHom (ZMod p)
  have hh := congrArg (Polynomial.map f) he
  rw [Polynomial.map_pow, map_pencil] at hh
  exact unitNotSquare h5 h7 h11 (f d)
    (fun h => hd ((ZMod.intCast_zmod_eq_zero_iff_dvd d p).mp h)) (S.map f) hh

/-- The integral pencil has no square root for any odd prime and any
integral coefficient, including zero, with no monicity hypothesis. -/
theorem integralNotSquare {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (d : ℤ) (S : ℤ[X]) : S^2 ≠ pencil ℤ p d := by
  by_cases hs : p ∈ ([3,5,7,11] : List ℕ)
  · exact exceptionalNotSquare hs d S
  by_cases hd : (p:ℤ) ∣ d
  · intro he
    apply EulerPrime.no_euler_square_of_prime_dvd hp d hd
    exact ⟨S, by simpa only [pencil,delta,← EulerIdentification.delta_eq_A_sub_const] using he⟩
  · have h4 : p ≠ 4 := by
      rintro rfl
      exact (by decide : ¬ Nat.Prime 4) Fact.out
    simp only [List.mem_cons, List.not_mem_nil, or_false, not_or] at hs
    exact unitIntegralNotSquare (by omega) (by tauto) (by tauto) d hd S

/-- For integral coefficients, a monic square over any characteristic-zero
field would descend first to the rationals and then to the integers. -/
theorem integralPencilNoMonicSquare {K : Type*} [Field K] [CharZero K]
    {p : ℕ} [Fact p.Prime] (hp : 2 < p) (d : ℤ) (S : K[X]) (hS : S.Monic) :
    S^2 ≠ pencil K p (d:K) := by
  intro he
  have hQ : (pencil ℚ p (d:ℚ)).map (algebraMap ℚ K) = pencil K p (d:K) := by
    simp [map_pencil]
  obtain ⟨R,hR,_,hR2⟩ := EulerDescent.monic_square_descends_rat S (pencil ℚ p (d:ℚ)) hS
    (he.trans hQ.symm)
  have hZ : (pencil ℤ p d).map (algebraMap ℤ ℚ) = pencil ℚ p (d:ℚ) := by
    simp [map_pencil]
  obtain ⟨T,_,_,hT⟩ := EulerDescent.monic_square_descends_int R (pencil ℤ p d) hR
    (hR2.trans hZ.symm)
  exact integralNotSquare hp d T hT

#print axioms integralNotSquare
#print axioms integralPencilNoMonicSquare
#print axioms unitIntegralNotSquare
end EulerIntegral
