import EulerIntegral
import EulerBadDen
import Mathlib.Algebra.Polynomial.Eval.Degree

/-! The integer and noninteger parameter cases, for the odd square supplied by
a competing polynomial decomposition. -/
namespace EulerRational
open Polynomial

theorem noOddSquare {p : ℕ} [Fact p.Prime] (hp : 2<p) (d : ℚ) (S : ℚ[X])
    (hS : S.Monic) (ho : S.comp (-X) = -S) : S^2 ≠ EulerSmall.pencil ℚ p d := by
  by_cases hd : d.den=1
  · rw [← Rat.coe_int_num_of_den_eq_one hd]
    exact EulerIntegral.integralPencilNoMonicSquare hp d.num S hS
  intro h
  have hpar : ∀ i, Even i → S.coeff i=0 := by
    intro i hi
    have hc := congrArg (fun T : ℚ[X] => T.coeff i) ho
    rw [show -(X:ℚ[X]) = C (-1:ℚ)*X from by simp,comp_C_mul_X_coeff,hi.neg_one_pow,coeff_neg] at hc
    linarith
  let g := Int.castRingHom ℚ
  have mapd (m : ℕ) : (EulerPrime.delta m).map g = EulerSmall.delta ℚ m := by
    rw [EulerIdentification.delta_eq_A_sub_const]
    exact EulerSmall.map_delta g m
  have hl : 0 < 2*p-2 := by omega
  have hdg : (EulerPrime.delta (2*p-2)).natDegree%4=0 := by
    rw [EulerPrime.delta_natDegree hl]
    have hodd := (Fact.out : p.Prime).odd_of_ne_two (by omega)
    obtain ⟨k,hk⟩ := hodd
    omega
  apply EulerBadDen.no_odd_square_of_denominator (EulerPrime.delta (2*p)) (EulerPrime.delta (2*p-2))
    (EulerPrime.delta_monic hl) hdg d hd S hS.ne_zero hpar
  simpa only [EulerSmall.pencil,show (Int.castRingHom ℚ) = g from rfl,mapd] using h

#print axioms noOddSquare
end EulerRational
