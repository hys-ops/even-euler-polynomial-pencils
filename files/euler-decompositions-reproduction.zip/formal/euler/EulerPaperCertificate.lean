import EulerSmall

/-! The four single-point certificates printed in the paper. -/
namespace EulerPaperCertificate
open Polynomial

private def alternatingValue (q m : ℕ) (x : ZMod (q+1)) : ZMod (q+1) :=
  ((List.range (q+1)).map fun j =>
    (if j % 2 = 0 then 1 else -1 : ZMod (q+1)) *
      (x + ((2*j+1 : ℕ) : ZMod (q+1)))^m).sum

private def difference (q m : ℕ) (x : ZMod (q+1)) : ZMod (q+1) :=
  alternatingValue q m x - alternatingValue q m 0

private theorem evaluation {q : ℕ} [Fact (q+1).Prime]
    (ho : Odd (q+1)) (ht : (2:ZMod (q+1)) ≠ 0) (m : ℕ) (x : ZMod (q+1)) :
    (EulerNormalized.A (ZMod (q+1)) m).eval x = alternatingValue q m x := by
  rw [EulerNormalized.alternating (p:=q+1) ho ht]
  unfold alternatingValue
  rw [← List.sum_toFinset _ (List.nodup_range (n:=q+1))]
  simp only [List.toFinset_range]
  apply Finset.sum_congr rfl
  intro j _
  simp only [neg_one_pow_eq_ite, Nat.even_iff]
  push_cast
  ring

private theorem rule {q : ℕ} [Fact (q+1).Prime]
    (ho : Odd (q+1)) (ht : (2:ZMod (q+1)) ≠ 0)
    (p : ℕ) (z b : ZMod (q+1))
    (hhi : difference q (2*p) z = b) (hlo : difference q (2*p-2) z = 0)
    (hns : ∀ y : ZMod (q+1), y*y ≠ b) (d : ℤ) (S : ℤ[X]) :
    S^2 ≠ EulerSmall.pencil ℤ p d := by
  intro he
  have h := congrArg (Polynomial.map (Int.castRingHom (ZMod (q+1)))) he
  rw [Polynomial.map_pow, EulerSmall.map_pencil] at h
  have hv := congrArg (Polynomial.eval z) h
  unfold difference at hhi hlo
  simp only [eval_pow, EulerSmall.pencil, eval_add, eval_mul, eval_C, EulerSmall.delta,
    eval_sub, evaluation ho ht, hhi, hlo, mul_zero, add_zero] at hv
  exact hns _ (by simpa only [pow_two] using hv)

set_option maxRecDepth 100000 in
set_option maxHeartbeats 4000000 in
theorem four_obstructions (p : ℕ) (hp : p = 3 ∨ p = 5 ∨ p = 7 ∨ p = 11)
    (d : ℤ) (S : ℤ[X]) : S^2 ≠ EulerSmall.pencil ℤ p d := by
  rcases hp with rfl | rfl | rfl | rfl
  · let : Fact (18+1).Prime := ⟨by decide⟩
    exact rule (q:=18) (by decide) (by decide) 3 5 12 (by decide) (by decide) (by decide) d S
  · let : Fact (96+1).Prime := ⟨by decide⟩
    exact rule (q:=96) (by decide) (by decide) 5 3 92 (by decide) (by decide) (by decide) d S
  · let : Fact (18+1).Prime := ⟨by decide⟩
    exact rule (q:=18) (by decide) (by decide) 7 8 10 (by decide) (by decide) (by decide) d S
  · let : Fact (28+1).Prime := ⟨by decide⟩
    exact rule (q:=28) (by decide) (by decide) 11 3 11 (by decide) (by decide) (by decide) d S

#print axioms four_obstructions
end EulerPaperCertificate
