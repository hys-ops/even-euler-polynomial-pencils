import EulerIntegralNormalization
import Mathlib.Algebra.Ring.GeomSum

/-! Descent of polynomial composition in characteristic zero. -/
noncomputable section
namespace RationalCompositionDescent
open Polynomial
open scoped Polynomial BigOperators
variable {K : Type*} [Field K] [CharZero K]

private abbrev ι (K : Type*) [Field K] [CharZero K] : ℚ →+* K := algebraMap ℚ K

omit [CharZero K] in
/-- The first differing coefficient of the powers of two monic polynomials
of the same degree, as a coefficient at the indexed power difference. -/
theorem pow_difference_coeff (V W : K[X]) (a b : ℕ) (vp : V.Monic) (wp : W.Monic)
    (vd : V.natDegree = b) (wd : W.natDegree = b) :
    (V^a-W^a).coeff ((a-1)*b+(V-W).natDegree) = (a : K)*(V-W).leadingCoeff := by
  let t := fun i : ℕ => V^i*W^(a-1-i)
  have dt (i : ℕ) (hi : i ∈ Finset.range a) : (t i).natDegree = (a-1)*b := by
    have hi' := Finset.mem_range.mp hi
    have h : i+(a-1-i)=a-1 := by omega
    dsimp [t]
    rw [natDegree_mul (pow_ne_zero _ vp.ne_zero) (pow_ne_zero _ wp.ne_zero),
      natDegree_pow, natDegree_pow, vd, wd, ← Nat.add_mul, h]
  have mt (i : ℕ) : (t i).Monic := (vp.pow i).mul (wp.pow _)
  have cb : (∑ i ∈ Finset.range a, t i).coeff ((a-1)*b) = (a : K) := by
    rw [finsetSum_coeff]
    calc ∑ i ∈ Finset.range a, (t i).coeff ((a-1)*b) = ∑ _i ∈ Finset.range a, (1 : K) := by
           apply Finset.sum_congr rfl
           intro i hi
           rw [← dt i hi, coeff_natDegree, (mt i).leadingCoeff]
         _ = _ := by simp
  rw [← geom_sum₂_mul]
  change ((∑ i ∈ Finset.range a, t i) * (V-W)).coeff _ = _
  rw [coeff_mul_add_eq_of_natDegree_le
    (natDegree_sum_le_of_forall_le _ t (fun i hi => (dt i hi).le)) le_rfl, cb, coeff_natDegree]

/-- Recover positive-degree coefficients of the normalized inner component. -/
private theorem recover_inner (F W : ℚ[X]) (V : K[X]) (a b : ℕ) (ha : 0 < a) (hb : 0 < b)
    (vmon : V.Monic) (vd : V.natDegree = b) (vzero : V.coeff 0 = 0)
    (wm : W.Monic) (wd : W.natDegree = b) (wzero : W.coeff 0 = 0)
    (bound : (F.map (ι K)-V^a).natDegree ≤ (a-1)*b)
    (improves : (V-W.map (ι K)).natDegree < b) : ∃ S : ℚ[X], S.map (ι K) = V := by
  let R := V-W.map (ι K)
  let j := R.natDegree
  let N := (a-1)*b+j
  have rz : R.coeff 0 = 0 := by simp [R,vzero,wzero]
  by_cases j0 : j = 0
  · have hR : R = 0 := by rw [eq_C_of_natDegree_eq_zero j0, rz, C_0]
    exact ⟨W, (sub_eq_zero.mp hR).symm⟩
  have jpos : 0 < j := Nat.zero_lt_of_ne_zero j0
  have jlt : j < b := improves
  have dw : (W.map (ι K)).natDegree = b := (natDegree_map_eq_of_injective (ι K).injective _).trans wd
  have powc := pow_difference_coeff V (W.map (ι K)) a b vmon (wm.map _) vd dw
  let q := (F-W^a).coeff N / (a : ℚ)
  have cq : (ι K) q = R.leadingCoeff := by
    have low : (F.map (ι K)-V^a).coeff N = 0 :=
      coeff_eq_zero_of_natDegree_lt (by dsimp only [N]; omega)
    have eqV : (F.map (ι K)).coeff N = (V^a).coeff N := sub_eq_zero.mp (by simpa using low)
    have hmap : ι K ((F-W^a).coeff N) = (a : K)*R.leadingCoeff := by
      rw [← coeff_map, Polynomial.map_sub, Polynomial.map_pow, coeff_sub, eqV, ← coeff_sub]
      exact powc
    dsimp only [q]
    rw [map_div₀, map_natCast, hmap]
    have an : (a : K) ≠ 0 := by exact_mod_cast ha.ne'
    field_simp
  let W' := W + monomial j q
  have small : (monomial j q).natDegree < W.natDegree := lt_of_le_of_lt (natDegree_monomial_le q) (wd ▸ jlt)
  have wm' : W'.Monic := by
    exact (leadingCoeff_add_of_degree_lt' (degree_lt_degree small)).trans wm.leadingCoeff
  have wd' : W'.natDegree = b := (natDegree_add_eq_left_of_natDegree_lt small).trans wd
  have wzero' : W'.coeff 0 = 0 := by
    simp [W',wzero,coeff_monomial, jpos.ne']
  have newres : V - W'.map (ι K) = R.eraseLead := by
    dsimp only [W']
    rw [Polynomial.map_add, map_monomial, cq, ← sub_sub]
    exact self_sub_monomial_natDegree_leadingCoeff R
  have smaller : (V-W'.map (ι K)).natDegree < j := by
    rw [newres]
    rcases R.eraseLead_natDegree_lt_or_eraseLead_eq_zero with hh | hh
    · exact hh
    · simpa [hh] using jpos
  exact recover_inner F W' V a b ha hb vmon vd vzero wm' wd' wzero' bound (lt_trans smaller jlt)
termination_by (V-W.map (ι K)).natDegree
decreasing_by exact smaller

/-- A monic, zero-constant inner component is rational if the monic composite is. -/
theorem normalized_inner (F : ℚ[X]) (U V : K[X]) (u : U.Monic) (v : V.Monic)
    (ua : 0 < U.natDegree) (vb : 0 < V.natDegree) (vz : V.coeff 0 = 0)
    (eq : F.map (ι K) = U.comp V) : ∃ W : ℚ[X], W.map (ι K) = V := by
  let b := V.natDegree
  let S : ℚ[X] := X^b
  have mono : S.Monic := monic_X_pow _
  have degS : S.natDegree = b := natDegree_X_pow _
  have zeroS : S.coeff 0 = 0 := by simp [S, coeff_X_pow, b, vb.ne'.symm]
  have monok : (S.map (ι K)).Monic := mono.map _
  have samed : (S.map (ι K)).natDegree = V.natDegree :=
    (natDegree_map_eq_of_injective (ι K).injective _).trans degS
  have degree_less : (V-S.map (ι K)).natDegree < b := by
    by_cases hv : V-S.map (ι K) = 0
    · simpa [hv,b] using vb
    apply natDegree_lt_natDegree hv
    exact degree_sub_lt_left (by rw [degree_eq_natDegree v.ne_zero, degree_eq_natDegree monok.ne_zero, samed]) v.ne_zero (v.leadingCoeff.trans monok.leadingCoeff.symm)
  have erase : U.comp V - V^U.natDegree = U.eraseLead.comp V := by
    have id := congrArg (fun P : K[X] => P.comp V) U.eraseLead_add_C_mul_X_pow
    simp only [add_comp, pow_comp, X_comp, u.leadingCoeff, C_1, one_mul] at id
    rw [← id, add_sub_cancel_right]
  refine recover_inner F S V U.natDegree b ua vb v rfl vz mono degS zeroS ?_ degree_less
  rw [eq, erase, natDegree_comp]
  exact Nat.mul_le_mul_right _ U.eraseLead_natDegree_le

/-- Once the monic inner component is rational, peel off successive leading
terms of the outer component. -/
theorem outer_of_substitution (F W : ℚ[X]) (U : K[X]) (w : W.Monic) (wb : 0 < W.natDegree)
    (eq : F.map (ι K) = U.comp (W.map (ι K))) : ∃ T : ℚ[X], T.map (ι K) = U := by
  have dw := natDegree_map_eq_of_injective (ι K).injective W
  have lc : ι K F.leadingCoeff = U.leadingCoeff := by
    rw [← leadingCoeff_map_of_injective (ι K).injective, eq,
        leadingCoeff_comp (by omega), (w.map _).leadingCoeff, one_pow, mul_one]
  by_cases u0 : U.natDegree = 0
  · refine ⟨C F.leadingCoeff, ?_⟩
    rw [map_C, lc]
    conv_rhs => rw [eq_C_of_natDegree_eq_zero u0]
    simp [leadingCoeff, u0]
  let Q := F - C F.leadingCoeff * W^U.natDegree
  have sq : Q.map (ι K) = U.eraseLead.comp (W.map (ι K)) := by
    dsimp only [Q]
    rw [Polynomial.map_sub, Polynomial.map_mul, map_C, Polynomial.map_pow, eq, lc]
    have id := congrArg (fun P : K[X] => P.comp (W.map (ι K))) U.eraseLead_add_C_mul_X_pow
    simp only [add_comp, mul_comp, C_comp, pow_comp, X_comp] at id
    rw [← id, add_sub_cancel_right]
  obtain ⟨T,ht⟩ := outer_of_substitution Q W U.eraseLead w wb sq
  refine ⟨T + C F.leadingCoeff * X^U.natDegree, ?_⟩
  rw [Polynomial.map_add, Polynomial.map_mul, map_C, Polynomial.map_pow, map_X, ht, lc,
      eraseLead_add_C_mul_X_pow]
termination_by U.natDegree
decreasing_by have h := U.eraseLead_natDegree_le; omega

/-- Every nonconstant polynomial composition over any characteristic-zero field,
whose composite has rational coefficients, descends to a rational composition
with both component degrees preserved. -/
theorem descend (F : ℚ[X]) (U V : K[X]) (hu : 0 < U.natDegree) (hv : 0 < V.natDegree)
    (eq : F.map (algebraMap ℚ K) = U.comp V) :
    ∃ A B : ℚ[X], A.comp B = F ∧ A.natDegree = U.natDegree ∧ B.natDegree = V.natDegree := by
  let l := V.leadingCoeff
  let t := V.coeff 0
  let W := C l⁻¹*(V-C t)
  let T : K[X] := C l*X+C t
  have lne : l ≠ 0 := leadingCoeff_ne_zero.mpr (ne_zero_of_natDegree_gt hv)
  have wd : W.natDegree = V.natDegree := by dsimp only [W]; rw [natDegree_C_mul (inv_ne_zero lne), natDegree_sub_C]
  have wm : W.Monic := by
    change (C l⁻¹*(V-C t)).leadingCoeff = 1
    rw [leadingCoeff_mul, leadingCoeff_C, leadingCoeff_sub_of_degree_lt
      (degree_lt_degree (by simpa only [natDegree_C] using hv)), inv_mul_cancel₀ lne]
  have wz : W.coeff 0 = 0 := by simp [W,t]
  have undo : T.comp W = V := by
    dsimp only [T,W]
    rw [add_comp, mul_comp, C_comp, X_comp, C_comp, ← mul_assoc, ← C_mul, mul_inv_cancel₀ lne,
      C_1, one_mul, sub_add_cancel]
  let P := U.comp T
  have pd : P.natDegree = U.natDegree := by simp [P,T,natDegree_comp,natDegree_C_mul_X _ lne]
  have id : F.map (ι K) = P.comp W := by dsimp only [P]; rw [comp_assoc,undo,eq]
  have plc : ι K F.leadingCoeff = P.leadingCoeff := by
    rw [← leadingCoeff_map_of_injective (ι K).injective, id, leadingCoeff_comp (by omega),
        wm.leadingCoeff,one_pow,mul_one]
  have pn : P.leadingCoeff ≠ 0 := leadingCoeff_ne_zero.mpr (ne_zero_of_natDegree_gt (n := 0) (by omega))
  let Q := P*C P.leadingCoeff⁻¹
  have qmon : Q.Monic := monic_mul_leadingCoeff_inv (leadingCoeff_ne_zero.mp pn)
  have qdeg : Q.natDegree = U.natDegree := by dsimp only [Q]; rw [natDegree_mul_C (inv_ne_zero pn), pd]
  let N := F * C F.leadingCoeff⁻¹
  have nid : N.map (ι K) = Q.comp W := by
    dsimp only [N, Q]
    rw [Polynomial.map_mul, map_C, map_inv₀, plc, id, mul_comp, C_comp]
  obtain ⟨B, bmap⟩ := normalized_inner N Q W qmon wm (by omega) (by omega) wz nid
  have bmon : B.Monic := by
    change B.leadingCoeff = 1
    apply (ι K).injective
    rw [map_one, ← leadingCoeff_map_of_injective (ι K).injective, bmap, wm.leadingCoeff]
  have bdeg : B.natDegree = V.natDegree := by
    rw [← natDegree_map_eq_of_injective (ι K).injective B, bmap, wd]
  obtain ⟨A,amap⟩ := outer_of_substitution F B P bmon (by omega) (bmap ▸ id)
  refine ⟨A,B,?_,?_,bdeg⟩
  · apply Polynomial.map_injective (ι K) (ι K).injective
    rw [map_comp, amap, bmap, id]
  · rw [← natDegree_map_eq_of_injective (ι K).injective A, amap, pd]

end RationalCompositionDescent
