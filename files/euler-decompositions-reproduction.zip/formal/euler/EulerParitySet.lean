import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Field.ZMod
import Mathlib.Data.Finset.Card
import Mathlib.Tactic.LinearCombination
import Mathlib.Tactic.Ring

/-! Concrete residue classes from the alternating Euler sum. -/
namespace EulerParity

def coord (p j : ℕ) : ZMod p := -(2*(j:ZMod p)+1)

def indices (p : ℕ) : Finset ℕ :=
  (Finset.range p).filter fun j => j%2 ≠ (p/2)%2

noncomputable def B (p : ℕ) : Finset (ZMod p) :=
  (indices p).image (coord p)

theorem coord_inj {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    Set.InjOn (coord p) (↑(indices p) : Set ℕ) := by
  intro i hi j hj he
  have h2 : (2:ZMod p) ≠ 0 := by
    change ((2:ℕ):ZMod p) ≠ 0
    intro h
    have := Nat.le_of_dvd (by decide : 0 < 2) ((ZMod.natCast_eq_zero_iff 2 p).mp h)
    omega
  have hc : 2*((i:ZMod p)-(j:ZMod p)) = 0 := by
    dsimp [coord] at he
    linear_combination -he
  have hej : (i:ZMod p) = (j:ZMod p) := sub_eq_zero.mp ((mul_eq_zero.mp hc).resolve_left h2)
  have hi' := Finset.mem_range.mp (Finset.mem_filter.mp hi).1
  have hj' := Finset.mem_range.mp (Finset.mem_filter.mp hj).1
  simpa [ZMod.val_natCast_of_lt hi',ZMod.val_natCast_of_lt hj'] using congrArg ZMod.val hej

/-- There is at least one selected member of each complete consecutive pair. -/
theorem card_lower {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    Fintype.card (ZMod p) ≤ 2*(B p).card+1 := by
  rw [ZMod.card,B,Finset.card_image_of_injOn (coord_inj h5)]
  let f := fun i : ℕ => 2*i + (1-(p/2)%2)
  have hle : (Finset.range (p/2)).card ≤ (indices p).card := by
    apply Finset.card_le_card_of_injOn f
    · intro i hi
      have hi' := Finset.mem_range.mp hi
      apply Finset.mem_filter.mpr
      dsimp [f]
      exact ⟨Finset.mem_range.mpr (by omega),by omega⟩
    · intro i _ j _ hij
      dsimp [f] at hij
      omega
  rw [Finset.card_range] at hle
  omega

private theorem neg_mem {p : ℕ} [Fact p.Prime] (h5 : 5 < p) {z : ZMod p}
    (hz : z ∈ B p) : -z ∈ B p := by
  obtain ⟨j,hj,rfl⟩ := Finset.mem_image.mp hz
  obtain ⟨hj,hs⟩ := Finset.mem_filter.mp hj
  have hj' := Finset.mem_range.mp hj
  obtain ⟨k,hk⟩ := (Fact.out : p.Prime).odd_of_ne_two (by omega)
  refine Finset.mem_image.mpr ⟨p-1-j,Finset.mem_filter.mpr ⟨Finset.mem_range.mpr (by omega),by omega⟩,?_⟩
  simp only [coord, neg_neg]
  rw [Nat.cast_sub (by omega : j ≤ p-1), Nat.cast_sub (by omega : 1 ≤ p),
    ZMod.natCast_self, Nat.cast_one]
  ring

theorem symmetric {p : ℕ} [Fact p.Prime] (h5 : 5 < p) :
    ∀ z, z ∈ B p ↔ -z ∈ B p := by
  intro z
  exact ⟨neg_mem h5,fun h => by simpa using neg_mem h5 h⟩

#print axioms card_lower
#print axioms symmetric
end EulerParity
