import EulerEight
import Mathlib.FieldTheory.IsAlgClosed.Basic
import Mathlib.FieldTheory.Separable

/-! Exact boundary when the parameter of the octic is allowed to be algebraic. -/
namespace EulerEightExceptions
open Polynomial EulerEight
noncomputable section
variable {K : Type*} [Field K] [CharZero K]

def discriminatingCubic : K[X] := X^3 - 6*X^2-8*X+56

/-- Nonstandard means that the nonlinear inner factor is not an affine transform of X²−X. -/
def Extra (c : K) : Prop :=
  ∃ P Q : K[X], P.comp Q = eulerCombination c ∧ 2 ≤ P.natDegree ∧ 2 ≤ Q.natDegree ∧
    ¬ ∃ a b : K, a ≠ 0 ∧ Q=C a*(X^2-X)+C b

theorem extra_iff (c : K) : Extra c ↔ c^3-6*c^2-8*c+56=0 := by
  constructor
  · rintro ⟨P,Q,h,hp,hq,hn⟩
    by_contra hc
    exact hn (eulerEight_unique_inner_of_obstruction c hc P Q h hp hq)
  · intro hc
    let s := translation c
    let b := 5-3*(c/2-1)^2/2
    let dc := quartic c (-s)
    let P : K[X] := X^2+C b*X+C dc
    let Q : K[X] := ((X-C (1/2))^2+C s)^2
    have hp : P.natDegree=2 := by dsimp [P]; compute_degree!
    have hq : Q.natDegree=4 := by dsimp [Q]; compute_degree!
    refine ⟨P,Q,?_,by omega,by omega,?_⟩
    · apply Polynomial.funext; intro x
      simp only [P,Q,eval_comp,eval_add,eval_sub,eval_mul,eval_pow,eval_C,eval_X,
        eval_eulerCombination,centeredE6,centeredE8,dc,b,s,translation,quartic]
      linear_combination -((x-1/2)^2+(c-7)/4)/8 * hc
    · rintro ⟨a,d,ha,he⟩
      have he2 : (C a * (X^2-X) + C d).natDegree = 2 := by compute_degree!
      rw [he, he2] at hq; omega

theorem extra_count [IsAlgClosed K] : {c : K | Extra c}.ncard = 3 := by
  classical
  let f : K[X] := discriminatingCubic
  have hdeg : f.natDegree=3 := by dsimp [f,discriminatingCubic]; compute_degree!
  have hn : f ≠ 0 := by intro hz; simp [hz] at hdeg
  have he : {c : K | Extra c} = (↑f.roots.toFinset : Set K) := by
    ext c
    simp only [Set.mem_ofPred_eq,Finset.mem_coe,Multiset.mem_toFinset,mem_roots hn,IsRoot,extra_iff]
    simp [f,discriminatingCubic]
  have hsep : f.Separable := by
    refine ⟨C (9/2056) - C (45/2056)*X,
      C (15/2056)*X^2-C (33/2056)*X-C (97/1028),?_⟩
    apply Polynomial.funext; intro x
    simp [f,discriminatingCubic,derivative_sub,derivative_add,derivative_mul, derivative_pow]
    ring
  rw [he,Set.ncard_coe_finset,Multiset.toFinset_card_of_nodup (nodup_roots hsep),
    splits_iff_card_roots.mp (IsAlgClosed.splits f),hdeg]
end
end EulerEightExceptions
