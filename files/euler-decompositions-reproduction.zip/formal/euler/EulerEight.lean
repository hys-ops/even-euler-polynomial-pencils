import ReflectionPolynomial
import Mathlib.RingTheory.Polynomial.RationalRoot
import Mathlib.Algebra.Polynomial.Degree.Lemmas
import Mathlib.Algebra.Polynomial.Expand
import Mathlib.Algebra.Polynomial.Roots
import Mathlib.Algebra.Polynomial.Eval.Degree
import Mathlib.Tactic.ComputeDegree
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.FinCases
import Mathlib.Tactic.Linarith
import Mathlib.Tactic.LinearCombination
import Mathlib.Data.ZMod.Basic
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Algebra.CharZero.Infinite

namespace EulerEight

noncomputable section

open Polynomial

/-- The scalar obstruction after shifting the quartic to remove its cubic term. -/
def obstruction (c : ℚ) : ℚ := c ^ 3 - 6*c^2 - 8*c + 56

theorem obstruction_ne_zero (c : ℚ) : obstruction c ≠ 0 := by
  intro h
  let r : ℚ := c / 2
  let f : ℤ[X] := X^3 - C 3*X^2 - C 2*X + C 7
  have hf : f.Monic := by dsimp [f]; monicity!
  have hr : aeval r f = 0 := by
    simp only [f, r, map_add, map_sub, map_mul, map_pow, aeval_X, aeval_C]
    norm_num
    unfold obstruction at h
    linear_combination h/8
  obtain ⟨z, hz, _⟩ := exists_integer_of_is_root_of_monic hf hr
  have hzq : (z : ℚ)^3 - 3*(z : ℚ)^2 - 2*(z : ℚ) + 7 = 0 := by
    rw [hz] at hr
    have hzcast : (algebraMap ℤ ℚ) z = (z : ℚ) := rfl
    simpa only [f, map_add, map_sub, map_mul, map_pow, aeval_X, aeval_C, map_ofNat, hzcast] using hr
  have hzZ : z^3 - 3*z^2 - 2*z + 7 = 0 := by exact_mod_cast hzq
  have hzmod : (z : ZMod 2)^3 - 3*(z : ZMod 2)^2 - 2*(z : ZMod 2) + 7 = 0 := by
    exact_mod_cast congrArg (Int.castRingHom (ZMod 2)) hzZ
  have hn : ∀ w : ZMod 2, w^3 - 3*w^2 - 2*w + 7 ≠ 0 := by decide
  exact hn _ hzmod

variable {K : Type*} [Field K] [CharZero K]

def quartic (c y : K) : K :=
  y ^ 4 + (c-7)*y^3 + (175/8 - 15*c/4)*y^2
    + (75*c/16 - 427/16)*y + 1385/256 - 61*c/64

def translation (c : K) : K := (c-7)/4

theorem reflection (c t : K) :
    quartic c (t - translation c) - quartic c (-t - translation c)
       = (c^3 - 6*c^2 - 8*c + 56)*t/4 := by
  unfold quartic translation
  ring

theorem coefficient_ne_zero (c : ℚ) :
    (c : K)^3 - 6*(c : K)^2 - 8*(c : K) + 56 ≠ 0 := by
  have hc := obstruction_ne_zero c
  unfold obstruction at hc
  intro h
  have hh : ((c^3 - 6*c^2 - 8*c + 56 : ℚ) : K) = ((0 : ℚ) : K) := by
    change (algebraMap ℚ K) _ = (algebraMap ℚ K) _
    have hcast : (algebraMap ℚ K) c = (c : K) := rfl
    simpa only [map_add, map_sub, map_mul, map_pow, map_ofNat, map_zero, hcast] using h
  exact hc (Rat.cast_injective (α := K) hh)

/-- No two quadratic maps over any characteristic-zero field compose to this quartic. -/
theorem no_quadratic_pair_of_obstruction (c : K) (hc : c^3-6*c^2-8*c+56 ≠ 0) (u v w a b d : K) (hu : u ≠ 0) (ha : a ≠ 0) :
    ¬ ∀ x : K, quartic (c : K) (x - translation (c : K)) =
      u*(a*x^2 + b*x + d)^2 + v*(a*x^2 + b*x + d) + w := by
  intro h
  have r1 := reflection (c : K) 1
  have r2 := reflection (c : K) 2
  rw [h 1, h (-1)] at r1
  rw [h 2, h (-2)] at r2
  have prod : u*a*b = 0 := by linear_combination (r2 - 2*r1)/24
  have hb : b = 0 := (mul_eq_zero.mp prod).resolve_left (mul_ne_zero hu ha)
  rw [hb] at r1
  apply hc
  linear_combination -4*r1


def quarticPolynomial (c : K) : K[X] :=
  X^4 + C (c-7)*X^3 + C (175/8 - 15*c/4)*X^2
    + C (75*c/16 - 427/16)*X + C (1385/256 - 61*c/64)

theorem eval_quarticPolynomial (c x : K) : (quarticPolynomial c).eval x = quartic c x := by
  simp [quarticPolynomial, quartic]
  ring

omit [CharZero K] in
private theorem degree_two_eval (p : K[X]) (hp : p.natDegree = 2) (x : K) :
    p.eval x = p.coeff 2*x^2 + p.coeff 1*x + p.coeff 0 := by
  rw [eval_eq_sum_range' (n := 3) (by omega)]
  simp [Finset.sum_range_succ]
  ring

/-- Every functional decomposition of the quartic quotient has a linear or constant factor. -/
theorem quartic_indecomposable_of_obstruction (c : K) (hc : c^3-6*c^2-8*c+56 ≠ 0) (p q : K[X])
    (h : p.comp q = quarticPolynomial (c : K)) : p.natDegree ≤ 1 ∨ q.natDegree ≤ 1 := by
  let shift : K[X] := X - C (translation c)
  let centered := (quarticPolynomial c).comp shift
  let a := (c^3-6*c^2-8*c+56)/4
  have ha : a ≠ 0 := div_ne_zero hc (by norm_num)
  have href : centered - centered.comp (-X) = C a * X := by
    apply Polynomial.funext
    intro x
    simp only [centered, shift, eval_sub, eval_comp, eval_X, eval_C, eval_neg,
      eval_mul, eval_quarticPolynomial]
    rw [reflection]
    dsimp [a]
    ring
  have hdecomp : centered = p.comp (q.comp shift) := by
    change (quarticPolynomial c).comp shift = _
    rw [← h,comp_assoc]
  have hi := ReflectionPolynomial.indecomposable_of_reflection_linear ha href hdecomp
  simpa [shift,natDegree_comp] using hi

theorem quartic_indecomposable (c : ℚ) (p q : K[X]) (h : p.comp q = quarticPolynomial (c : K)) :
    p.natDegree ≤ 1 ∨ q.natDegree ≤ 1 :=
  quartic_indecomposable_of_obstruction (c : K) (coefficient_ne_zero c) p q h

omit [CharZero K] in
private theorem degree_four_eval (p : K[X]) (hp : p.natDegree = 4) (x : K) :
    p.eval x = p.coeff 4*x^4 + p.coeff 3*x^3 + p.coeff 2*x^2 + p.coeff 1*x + p.coeff 0 := by
  rw [eval_eq_sum_range' (n := 5) (by omega)]
  simp [Finset.sum_range_succ]
  ring

omit [CharZero K] in
private theorem top_ne_zero (p : K[X]) {d : ℕ} (hp : p.natDegree = d) (hd : 0 < d) :
    p.coeff d ≠ 0 := by
  rw [← hp, coeff_natDegree, leadingCoeff_ne_zero]
  intro hz
  simp [hz] at hp
  omega

def octicPolynomial (c : K) : K[X] := (quarticPolynomial c).comp (X^2)

/-- The centered ordinary Euler polynomials of orders six and eight. -/
def centeredE6 (t : K) : K := t^6 - 15/4*t^4 + 75/16*t^2 - 61/64
def centeredE8 (t : K) : K := t^8 - 7*t^6 + 175/8*t^4 - 427/16*t^2 + 1385/256

theorem octic_evaluation (c x : K) :
    (octicPolynomial c).eval x = centeredE8 x + c*centeredE6 x := by
  simp [octicPolynomial, eval_quarticPolynomial, quartic, centeredE6, centeredE8]
  ring

omit [CharZero K] in
private theorem octic_even_composition (c : K) (p q : K[X])
    (h : p.comp q = octicPolynomial (c : K)) (x : K) :
    p.eval (q.eval x) = p.eval (q.eval (-x)) := by
  calc
    _ = (octicPolynomial (c : K)).eval x := by rw [← eval_comp, h]
    _ = (octicPolynomial (c : K)).eval (-x) := by simp [octicPolynomial]
    _ = _ := by rw [← eval_comp, h]

private theorem odd_seventh_zero (s₇ s₅ s₃ s₁ : K)
    (h : ∀ t : K, s₇*t^7 + s₅*t^5 + s₃*t^3 + s₁*t = 0) : s₇ = 0 := by
  linear_combination -(h 1)/360 + (h 2)/360 - (h 3)/840 + (h 4)/5040

private theorem even_outer_two (c : K) (hc : c^3-6*c^2-8*c+56 ≠ 0) (p q : K[X])
    (h : p.comp q = octicPolynomial (c : K)) (hp : p.natDegree = 2) (hq : q.natDegree = 4) :
    False := by
  let u := p.coeff 2
  let v := p.coeff 1
  let a := q.coeff 4
  let b := q.coeff 3
  let d := q.coeff 2
  let e := q.coeff 1
  let f := q.coeff 0
  have hu : u ≠ 0 := top_ne_zero p hp (by decide)
  have ha : a ≠ 0 := top_ne_zero q hq (by decide)
  have odd (x : K) :
      (4*u*a*b)*x^7 + (4*u*(a*e+b*d))*x^5
        + (4*u*(b*f+d*e)+2*v*b)*x^3 + (4*u*e*f+2*v*e)*x = 0 := by
    have hpar := octic_even_composition c p q h x
    simp only [degree_two_eval p hp, degree_four_eval q hq] at hpar
    dsimp [u, v, a, b, d, e, f]
    linear_combination hpar
  have hb0 := odd_seventh_zero _ _ _ _ odd
  have hb : b = 0 := (mul_eq_zero.mp hb0).resolve_left (mul_ne_zero (mul_ne_zero (by norm_num) hu) ha)
  have e1 := odd 1
  have e2 := odd 2
  have e3 := odd 3
  rw [hb] at e1 e2 e3
  have he0 : u*a*e = 0 := by
    linear_combination (5*e1-4*e2+e3)/480
  have he : e = 0 := (mul_eq_zero.mp he0).resolve_left (mul_ne_zero hu ha)
  let r : K[X] := C a*X^2 + C d*X + C f
  have hqr : q = r.comp (X^2) := by
    apply Polynomial.funext
    intro x
    simp only [degree_four_eval q hq, eval_comp, eval_pow, eval_X]
    change a*x^4 + b*x^3 + d*x^2 + e*x + f = r.eval (x^2)
    simp only [r, eval_add, eval_mul, eval_pow, eval_X, eval_C, hb, he]
    ring
  have hh : p.comp r = quarticPolynomial (c : K) := by
    apply expand_injective (R := K) (n := 2) (by decide)
    simpa only [expand_eq_comp_X_pow, comp_assoc, ← hqr, octicPolynomial] using h
  have hr : r.natDegree = 2 := by unfold r; compute_degree!
  have := quartic_indecomposable_of_obstruction c hc p r hh
  omega

private theorem even_inner_two (c : K) (p q : K[X])
    (h : p.comp q = octicPolynomial (c : K)) (hp : p.natDegree = 4) (hq : q.natDegree = 2) :
    ∃ a d : K, a ≠ 0 ∧ q = C a * X^2 + C d := by
  let s := p.coeff 4
  let r := p.coeff 3
  let u := p.coeff 2
  let v := p.coeff 1
  let a := q.coeff 2
  let b := q.coeff 1
  let d := q.coeff 0
  have hs : s ≠ 0 := top_ne_zero p hp (by decide)
  have ha : a ≠ 0 := top_ne_zero q hq (by decide)
  have odd (x : K) :
      (8*s*a^3*b)*x^7 + (24*s*a^2*b*d + 8*s*a*b^3 + 6*r*a^2*b)*x^5
        + (24*s*a*b*d^2 + 8*s*b^3*d + 12*r*a*b*d + 2*r*b^3 + 4*u*a*b)*x^3
        + (8*s*b*d^3 + 6*r*b*d^2 + 4*u*b*d + 2*v*b)*x = 0 := by
    have hpar := octic_even_composition c p q h x
    simp only [degree_four_eval p hp, degree_two_eval q hq] at hpar
    dsimp [s, r, u, v, a, b, d]
    linear_combination hpar
  have hb0 := odd_seventh_zero _ _ _ _ odd
  have hb : b = 0 := (mul_eq_zero.mp hb0).resolve_left (mul_ne_zero (mul_ne_zero (by norm_num) hs) (pow_ne_zero _ ha))
  refine ⟨a, d, ha, Polynomial.funext (fun x => ?_)⟩
  simp only [degree_two_eval q hq, eval_add, eval_mul, eval_pow, eval_X, eval_C]
  change a*x^2 + b*x + d = a*x^2 + d
  rw [hb]
  ring

/-- Complete normalized degree-eight case: a nonlinear inner factor differs from
the centered square only by multiplication by a nonzero scalar and addition of a constant. -/
theorem octic_unique_inner_of_obstruction (c : K) (hc : c^3-6*c^2-8*c+56 ≠ 0) (p q : K[X])
    (h : p.comp q = octicPolynomial (c : K)) (hp : 2 ≤ p.natDegree) (hq : 2 ≤ q.natDegree) :
    ∃ a d : K, a ≠ 0 ∧ q = C a * X^2 + C d := by
  have hprod : p.natDegree*q.natDegree = 8 := by
    rw [← natDegree_comp, h, octicPolynomial, natDegree_comp]
    have h4 : (quarticPolynomial (c : K)).natDegree = 4 := by unfold quarticPolynomial; compute_degree!
    simp [h4]
  have ph := Nat.mul_le_mul_left p.natDegree hq
  have qh := Nat.mul_le_mul_right q.natDegree hp
  have hb : p.natDegree = 2 ∨ p.natDegree = 3 ∨ p.natDegree = 4 := by omega
  rcases hb with h2 | h3 | h4
  · have hq4 : q.natDegree = 4 := by rw [h2] at hprod; omega
    exact (even_outer_two c hc p q h h2 hq4).elim
  · rw [h3] at hprod
    omega
  · have hq2 : q.natDegree = 2 := by rw [h4] at hprod; omega
    exact even_inner_two c p q h h4 hq2

/-- Standard Euler normalization in the variable x, characterized by
Eₙ(x+1) + Eₙ(x) = 2xⁿ. -/
theorem euler_shift_identities (x : K) :
    centeredE6 (x + 1 - 1/2) + centeredE6 (x-1/2) = 2*x^6 ∧
    centeredE8 (x + 1 - 1/2) + centeredE8 (x-1/2) = 2*x^8 := by
  constructor <;> simp only [centeredE6, centeredE8] <;> ring

def eulerCombination (c : K) : K[X] :=
  (octicPolynomial c).comp (X - C (1/2))

theorem eval_eulerCombination (c x : K) :
    (eulerCombination c).eval x = centeredE8 (x-1/2) + c*centeredE6 (x-1/2) := by
  simp [eulerCombination, octic_evaluation]

/-- Every nonlinear factorization of E₈(x) + c E₆(x), over any characteristic-zero field
with rational parameter c, has inner factor a(x²−x)+d, with nonzero a. -/
theorem eulerEight_unique_inner_of_obstruction (c : K) (hc : c^3-6*c^2-8*c+56 ≠ 0) (p q : K[X])
    (h : p.comp q = eulerCombination (c : K)) (hp : 2 ≤ p.natDegree) (hq : 2 ≤ q.natDegree) :
    ∃ a d : K, a ≠ 0 ∧ q = C a * (X^2 - X) + C d := by
  let right : K[X] := X + C (1/2)
  let left : K[X] := X - C (1/2)
  have hshift : left.comp right = X := by simp [left, right]
  have hundo : right.comp left = X := by simp [left, right]
  have htrans : p.comp (q.comp right) = octicPolynomial (c : K) := by
    rw [← comp_assoc, h]
    change ((octicPolynomial (c : K)).comp left).comp right = _
    rw [comp_assoc, hshift, comp_X]
  have htdeg : 2 ≤ (q.comp right).natDegree := by simpa [right, natDegree_comp] using hq
  obtain ⟨a, d, ha, hcanonical⟩ := octic_unique_inner_of_obstruction c hc p _ htrans hp htdeg
  refine ⟨a, a/4+d, ha, ?_⟩
  have heval (x : K) := congrArg (fun f : K[X] => f.eval x) (congrArg (fun f : K[X] => f.comp left) hcanonical)
  apply Polynomial.funext
  intro x
  specialize heval x
  simp only [comp_assoc, hundo, comp_X, eval_comp, eval_add, eval_mul, eval_pow, eval_X, eval_C, left, eval_sub] at heval
  simp only [eval_add, eval_mul, eval_pow, eval_X, eval_C, eval_sub]
  rw [heval]
  ring

theorem eulerEight_unique_inner (c : ℚ) (p q : K[X])
    (h : p.comp q = eulerCombination (c : K)) (hp : 2 ≤ p.natDegree) (hq : 2 ≤ q.natDegree) :
    ∃ a d : K, a ≠ 0 ∧ q = C a * (X^2-X) + C d :=
  eulerEight_unique_inner_of_obstruction (c:K) (coefficient_ne_zero c) p q h hp hq

/-- A polynomial is uniquely determined by the sum of its translates by 0 and 1. -/
theorem shift_sum_injective (P Q : K[X])
    (h : ∀ x : K, P.eval (x+1) + P.eval x = Q.eval (x+1) + Q.eval x) : P = Q := by
  have hshift : (P-Q).comp (X+C 1) = -(P-Q) := by
    apply Polynomial.funext
    intro x
    simp only [eval_comp, eval_add, eval_X, eval_C, eval_sub, eval_neg]
    linear_combination h x
  have hc := congrArg leadingCoeff hshift
  rw [leadingCoeff_comp (by simp), (monic_X_add_C (1 : K)).leadingCoeff,
      one_pow, mul_one, leadingCoeff_neg] at hc
  apply sub_eq_zero.mp
  apply leadingCoeff_eq_zero.mp
  linear_combination hc/2

/-- Conjecture 1 in degree eight, for the Euler polynomials specified solely by
their defining identities. -/
theorem eulerEight_from_defining_identities (c : ℚ) (E6 E8 P Q : K[X])
    (h6 : ∀ x : K, E6.eval (x+1) + E6.eval x = 2*x^6)
    (h8 : ∀ x : K, E8.eval (x+1) + E8.eval x = 2*x^8)
    (hcomp : P.comp Q = E8 + C (c : K)*E6) (hp : 2 ≤ P.natDegree) (hq : 2 ≤ Q.natDegree) :
    ∃ a d : K, a ≠ 0 ∧ Q = C a * (X^2 - X) + C d := by
  apply eulerEight_unique_inner c P Q _ hp hq
  rw [hcomp]
  apply shift_sum_injective
  intro x
  simp only [eval_eulerCombination, eval_add, eval_mul, eval_C]
  obtain ⟨k6, k8⟩ := euler_shift_identities x
  linear_combination h8 x + (c : K) * h6 x - k8 - (c : K) * k6

end

end EulerEight
