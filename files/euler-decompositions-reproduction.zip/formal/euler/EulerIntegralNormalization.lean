import EulerDenominator
import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.Tactic.FieldSimp

/-! Primitive normalization of a rational decomposition of an integral polynomial. -/
noncomputable section
namespace EulerIntegralNormalization
open Polynomial
open scoped Polynomial nonZeroDivisors

abbrev ι : ℤ →+* ℚ := algebraMap ℤ ℚ

/-- A primitive integral inner polynomial whose constant term vanishes detects
integrality of the outer polynomial. -/
theorem outer_integral (V : ℤ[X]) (prim : V.IsPrimitive) (v0 : V.coeff 0 = 0)
    (U : ℚ[X]) (G : ℤ[X]) (hg : G.map ι = U.comp (V.map ι)) :
    ∃ A : ℤ[X], A.map ι = U := by
  have vc : (V.map ι).eval 0 = 0 := by rw [← coeff_zero_eq_eval_zero, coeff_map, v0, map_zero]
  have z : ι (G.coeff 0) = U.coeff 0 := by
    have e := congrArg (Polynomial.eval 0) hg
    rw [eval_comp, vc, ← coeff_zero_eq_eval_zero, ← coeff_zero_eq_eval_zero, coeff_map] at e
    exact e
  by_cases u0 : U.natDegree = 0
  · refine ⟨C (G.coeff 0), ?_⟩
    rw [map_C, z, ← eq_C_of_natDegree_eq_zero u0]
  have fact : U.divX.comp (V.map ι) * V.map ι = (G - C (G.coeff 0)).map ι := by
    have hh := congrArg (fun P : ℚ[X] => P.comp (V.map ι)) (divX_mul_X_add U)
    simp only [add_comp, mul_comp, X_comp, C_comp] at hh
    rw [Polynomial.map_sub, map_C, hg, z, ← hh]
    ring
  have li : U.divX.comp (V.map ι) * V.map ι ∈ Polynomial.lifts ι :=
    ⟨G-C (G.coeff 0), fact.symm⟩
  obtain ⟨S, hs⟩ := (prim.mul_map_mem_lifts_iff.mp li : U.divX.comp (V.map ι) ∈ lifts ι)
  obtain ⟨A,ha⟩ := outer_integral V prim v0 U.divX S hs
  refine ⟨A*X+C (G.coeff 0), ?_⟩
  rw [Polynomial.map_add, Polynomial.map_mul, map_X, map_C, ha, z, divX_mul_X_add]
termination_by U.natDegree
decreasing_by rw [natDegree_divX_eq_natDegree_tsub_one]; omega

/-- Clear denominators and divide out the content of a rational polynomial. -/
theorem primitive_multiple (P : ℚ[X]) (hP : P ≠ 0) :
    ∃ (a : ℚ) (W : ℤ[X]), a ≠ 0 ∧ W.IsPrimitive ∧ W.map ι = C a*P := by
  let T := IsLocalization.integerNormalization (nonZeroDivisors ℤ) P
  obtain ⟨b, b0, hb⟩ := IsLocalization.integerNormalization_spec (nonZeroDivisors ℤ) P
  change T.map ι = b • P at hb
  rw [Algebra.smul_def, Polynomial.algebraMap_apply] at hb
  have ht : T ≠ 0 := fun h => hP (IsFractionRing.integerNormalization_eq_zero_iff.mp h)
  have hc : (ι T.content : ℚ) ≠ 0 := by
    change (T.content : ℚ) ≠ 0
    exact_mod_cast (content_eq_zero_iff.not.mpr ht)
  have hb' : ι b ≠ 0 := by
    change (b : ℚ) ≠ 0
    exact_mod_cast (nonZeroDivisors.ne_zero b0)
  refine ⟨ι b / ι T.content,T.primPart,div_ne_zero hb' hc,T.isPrimitive_primPart,?_⟩
  have eq : C (ι T.content) * T.primPart.map ι = C (ι b) * P := by
    rw [← map_C, ← Polynomial.map_mul, ← eq_C_content_mul_primPart, hb]
  ext i
  have e := congrArg (fun H : ℚ[X] => H.coeff i) eq
  simp only [coeff_C_mul] at e ⊢
  field_simp
  linear_combination e

/-- A rational decomposition of an integer polynomial can be replaced by an
integer decomposition of the same degrees if the right component is nonconstant. -/
theorem integral_factors (G : ℤ[X]) (U V : ℚ[X]) (vpos : 0 < V.natDegree)
    (hg : G.map ι = U.comp V) :
    ∃ (A B : ℤ[X]), A.comp B = G ∧ A.natDegree = U.natDegree ∧ B.natDegree = V.natDegree := by
  let t := V.coeff 0
  let W := V - C t
  have nw : W.natDegree = V.natDegree := natDegree_sub_C
  have w0 : W.coeff 0 = 0 := by simp [W,t]
  have wne : W ≠ 0 := ne_zero_of_natDegree_gt (n := 0) (by omega)
  obtain ⟨a,B,ha,prim,scale⟩ := primitive_multiple W wne
  have inj : Function.Injective ι := Int.cast_injective
  have b0 : B.coeff 0 = 0 := by
    apply inj
    have e := congrArg (fun P : ℚ[X] => P.coeff 0) scale
    simpa only [coeff_map, coeff_C_mul, w0, mul_zero, map_zero] using e
  let T : ℚ[X] := C a⁻¹*X + C t
  have undo : T.comp (B.map ι) = V := by
    dsimp only [T]
    rw [add_comp, mul_comp, C_comp, X_comp, C_comp, scale, ← mul_assoc,
      ← C_mul, inv_mul_cancel₀ ha, C_1, one_mul]
    dsimp only [W]
    abel
  have h : G.map ι = (U.comp T).comp (B.map ι) := by rw [comp_assoc, undo, hg]
  obtain ⟨A,eqA⟩ := outer_integral B prim b0 _ G h
  refine ⟨A,B,?_,?_,?_⟩
  · apply Polynomial.map_injective ι inj
    rw [map_comp, eqA, comp_assoc, undo, hg]
  · rw [← natDegree_map_eq_of_injective inj A, eqA, natDegree_comp]
    simp [T, natDegree_C_mul_X _ (inv_ne_zero ha)]
  · rw [← natDegree_map_eq_of_injective inj B, scale, natDegree_C_mul ha, nw]

/-- The denominator theorem directly for arbitrary rational factors of the pencil. -/
theorem rational_pencil_obstruction (D : ℕ) (c : ℤ) (E H : ℤ[X]) (U V : ℚ[X])
    (hd : 1 < D) (cop : c.natAbs.Coprime D) (em : E.Monic) (hm : H.Monic)
    (gap : H.natDegree+2 = E.natDegree) (en : E.nextCoeff = -((E.natDegree/2 : ℕ) : ℤ))
    (hu : 2 ≤ U.natDegree) (hv : 3 ≤ V.natDegree)
    (comp : (C (D : ℤ)*E + C c*H).map ι = U.comp V) :
    D = 4 ∧ E.natDegree % 4 = 2 := by
  obtain ⟨A,B,h,ha,hb⟩ := integral_factors _ _ _ (by omega) comp
  exact EulerDenominator.integral_pencil_obstruction D c E H A B hd cop em hm gap en
    (ha ▸ hu) (hb ▸ hv) h

end EulerIntegralNormalization
