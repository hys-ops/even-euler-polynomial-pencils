import Mathlib.Data.Nat.Prime.Int
import Mathlib.Algebra.Field.ZMod
import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.Data.ZMod.Basic
import Mathlib.Data.Rat.Cast.CharZero
import Mathlib.Tactic.Ring
import Mathlib.Tactic.FieldSimp

/-! At a prime of the parameter denominator the primitive reduction of a
square of an odd polynomial has degree 2 mod 4. -/
namespace EulerBadDen
open Polynomial
open scoped nonZeroDivisors
private abbrev ι := Int.castRingHom ℚ

private theorem primitiveRep (S : ℚ[X]) (hS : S ≠ 0) :
    ∃ U : ℤ[X], ∃ k : ℚ, k ≠ 0 ∧ U.IsPrimitive ∧ S = C k * U.map ι := by
  let V := IsLocalization.integerNormalization (nonZeroDivisors ℤ) S
  obtain ⟨b,hb,(H : V.map (algebraMap ℤ ℚ) = _)⟩ :=
    IsLocalization.integerNormalization_spec (nonZeroDivisors ℤ) S
  have hb' : b ≠ 0 := nonZeroDivisors.ne_zero hb
  have hh : V.map ι = C (b:ℚ) * S := by simpa [Algebra.smul_def] using H
  have hV : V ≠ 0 := by
    intro h
    simp [h,hS,hb'] at hh
  have ht : V.content ≠ 0 := content_eq_zero_iff.not.mpr hV
  refine ⟨V.primPart, (V.content : ℚ)/(b:ℚ), div_ne_zero (Int.cast_ne_zero.mpr ht)
    (Int.cast_ne_zero.mpr hb'), V.isPrimitive_primPart, ?_⟩
  have hv := congrArg (fun f : ℤ[X] => f.map ι) (eq_C_content_mul_primPart V)
  simp only [Polynomial.map_mul,map_C] at hv
  rw [hh] at hv
  have hbin : (b:ℚ) ≠ 0 := Int.cast_ne_zero.mpr hb'
  have eq : ((b:ℚ)) * ((V.content:ℚ)/b) = V.content := by field_simp
  apply mul_left_cancel₀ (C_ne_zero.mpr hbin)
  rw [← mul_assoc,← C_mul,eq]
  exact hv

private theorem primitive_mod_ne {q : ℕ} [Fact q.Prime] {U : ℤ[X]} (hU : U.IsPrimitive) :
    U.map (Int.castRingHom (ZMod q)) ≠ 0 := by
  intro h
  have hd : C (q:ℤ) ∣ U := (C_dvd_iff_dvd_coeff _ _).mpr (fun j => by
    apply (ZMod.intCast_zmod_eq_zero_iff_dvd _ _).mp
    have hc := congrArg (fun f : (ZMod q)[X] => f.coeff j) h
    simpa using hc)
  exact (Nat.prime_iff_prime_int.mp (Fact.out : q.Prime)).not_isUnit
    (isPrimitive_iff_isUnit_of_C_dvd.mp hU q hd)

private theorem coprimeRes {q : ℕ} [Fact q.Prime] (a : ℚ) (h : (a.den : ZMod q)=0) :
    (a.num : ZMod q) ≠ 0 := by
  intro H
  have hd := (ZMod.natCast_eq_zero_iff a.den q).mp h
  have hn := (ZMod.intCast_zmod_eq_zero_iff_dvd a.num q).mp H
  have ha : q ∣ a.num.natAbs := by exact_mod_cast Int.natAbs_dvd_natAbs.mpr hn
  exact (Fact.out : q.Prime).not_dvd_one (a.reduced.gcd_eq_one ▸ Nat.dvd_gcd ha hd)



private theorem clear_ratio (W V : ℤ[X]) (a : ℚ) (h : W.map ι = C a * V.map ι) :
    C (a.den:ℤ) * W = C a.num * V := by
  apply Polynomial.map_injective ι Int.cast_injective
  simp only [Polynomial.map_mul,map_C, Int.coe_castRingHom, Int.cast_natCast, h]
  rw [← mul_assoc, ← C_mul]
  have hm := (div_eq_iff (by exact_mod_cast a.den_nz : (a.den:ℚ) ≠ 0)).mp a.num_div_den
  rw [mul_comm (a.den:ℚ) a, ← hm]

/-- A rational scalar multiple of a primitive integral square that has
nonzero reduction still has the degree of the square after reduction. -/
private theorem reductionSquareDegree {q : ℕ} [Fact q.Prime] {W U : ℤ[X]}
    (hu : U.IsPrimitive) (hw : W.map (Int.castRingHom (ZMod q)) ≠ 0) (a : ℚ)
    (H : W.map ι = C a*(U^2).map ι) :
    (W.map (Int.castRingHom (ZMod q))).natDegree =
      2*(U.map (Int.castRingHom (ZMod q))).natDegree := by
  let f := Int.castRingHom (ZMod q)
  have hu' := primitive_mod_ne (q:=q) hu
  have eq := congrArg (fun P : ℤ[X] => P.map f) (clear_ratio W (U^2) a H)
  simp only [Polynomial.map_mul, map_C,Polynomial.map_pow] at eq
  have den : (a.den : ZMod q) ≠ 0 := by
    intro e
    have hn := coprimeRes a e
    have he : f (a.den:ℤ)=0 := by simpa [f] using e
    rw [he,C_0,zero_mul] at eq
    exact (mul_ne_zero (C_ne_zero.mpr hn) (pow_ne_zero _ hu')) eq.symm
  have num : (a.num : ZMod q) ≠ 0 := by
    intro he
    have e : f a.num=0 := he
    rw [e,C_0,zero_mul] at eq
    exact (mul_ne_zero (C_ne_zero.mpr (by simpa [f] using den)) hw) eq
  apply_fun Polynomial.natDegree at eq
  rw [natDegree_C_mul (by simpa [f] using den), natDegree_C_mul (show f a.num ≠ 0 from num), natDegree_pow] at eq
  simpa [f,Nat.mul_comm] using eq

/-- If the lower summand has monic degree 0 modulo 4, a nonintegral rational
coefficient makes an odd-polynomial square impossible. -/
theorem no_odd_square_of_denominator (P Q : ℤ[X]) (hQ : Q.Monic)
    (hdeg : Q.natDegree % 4 = 0) (d : ℚ) (hd : d.den ≠ 1)
    (S : ℚ[X]) (hS : S ≠ 0) (ho : ∀ i, Even i → S.coeff i = 0)
    (h : S^2=P.map ι + C d*Q.map ι) : False := by
  obtain ⟨q,hq,hdiv⟩ := Nat.exists_prime_and_dvd hd
  let : Fact q.Prime := ⟨hq⟩
  let f := Int.castRingHom (ZMod q)
  let W : ℤ[X] := C (d.den:ℤ)*P + C d.num*Q
  have hdn : (d.den : ZMod q) = 0 := (ZMod.natCast_eq_zero_iff _ _).mpr hdiv
  have hnum := coprimeRes d hdn
  have Wmod : W.map f = C (d.num : ZMod q) * Q.map f := by
    simp only [W,f,Polynomial.map_add,Polynomial.map_mul,map_C,Int.coe_castRingHom,Int.cast_natCast,hdn,C_0,zero_mul,zero_add]
  have Wne : W.map f ≠ 0 := Wmod ▸ mul_ne_zero (C_ne_zero.mpr hnum) (hQ.map f).ne_zero
  have Wdeg : (W.map f).natDegree = Q.natDegree := by rw [Wmod,natDegree_C_mul hnum,hQ.natDegree_map]
  obtain ⟨U,k,hk,hU,rep⟩ := primitiveRep S hS
  have eqden := (div_eq_iff (by exact_mod_cast d.den_nz : (d.den:ℚ)≠0)).mp d.num_div_den
  have Wrat : W.map ι = C (d.den:ℚ) * S^2 := by
    simp only [W,Polynomial.map_add,Polynomial.map_mul,map_C,Int.coe_castRingHom,Int.cast_natCast,h]
    rw [mul_add,← mul_assoc,← C_mul,mul_comm (d.den:ℚ) d,← eqden]
  have hr : W.map ι = C ((d.den:ℚ)*k^2)*(U^2).map ι := by
    rw [Wrat,rep,mul_pow,Polynomial.map_pow,← map_pow, ← mul_assoc, ← C_mul]
  have huD := reductionSquareDegree hU Wne _ hr
  have hz : ∀ i, Even i → (U.map f).coeff i = 0 := by
    intro i hi
    have hcoeff := congrArg (fun R : ℚ[X] => R.coeff i) rep
    rw [ho i hi,coeff_C_mul, coeff_map] at hcoeff
    have h0 : U.coeff i = 0 := Int.cast_injective ((mul_eq_zero.mp hcoeff.symm).resolve_left hk)
    simp [h0]
  have hodd : ¬ Even (U.map f).natDegree := by
    intro he
    exact (leadingCoeff_ne_zero.mpr (primitive_mod_ne (q:=q) hU)) (hz _ he)
  change (W.map f).natDegree = 2*(U.map f).natDegree at huD
  rw [Wdeg] at huD
  rw [Nat.even_iff] at hodd
  omega
end EulerBadDen
