import Mathlib.RingTheory.Polynomial.GaussLemma
import Mathlib.RingTheory.Polynomial.RationalRoot
import Mathlib.Algebra.Polynomial.Reverse
import Mathlib.Algebra.Field.Subfield.Basic
import Mathlib.Algebra.Algebra.Rat
import Mathlib.Tactic.FieldSimp
import Mathlib.Tactic.Ring

namespace EulerDescent

noncomputable section

open Polynomial Finset

/-- Gauss descent for a monic square root of an integral polynomial. -/
theorem monic_square_descends_int (S : ℚ[X]) (P : ℤ[X]) (hS : S.Monic)
    (hsq : S^2 = P.map (algebraMap ℤ ℚ)) :
    ∃ R : ℤ[X], R.Monic ∧ R.map (algebraMap ℤ ℚ) = S ∧ R^2 = P := by
  let f := algebraMap ℤ ℚ
  have hf : Function.Injective f := Int.cast_injective
  have hP : P.Monic := Polynomial.monic_of_injective hf (hsq ▸ hS.pow 2)
  have hd : S ∣ P.map f := by rw [← hsq]; exact dvd_pow_self _ (by decide : 2 ≠ 0)
  obtain ⟨R,hR⟩ := IsIntegrallyClosed.eq_map_mul_C_of_dvd ℚ hP hd
  have hmap : R.map f = S := by simpa [f, hS.leadingCoeff] using hR
  refine ⟨R, Polynomial.monic_of_injective hf (hmap ▸ hS), hmap, ?_⟩
  apply Polynomial.map_injective f hf
  simpa only [Polynomial.map_pow, hmap] using hsq

variable {K : Type*} [Field K] [CharZero K]

/-- With constant term one the square-coefficient relation is triangular:
the two endpoint terms give twice the unknown coefficient. -/
private theorem coeff_mem_of_square (L : Subfield K) (R : K[X]) (h0 : R.coeff 0 = 1)
    (h : ∀ n, (R*R).coeff n ∈ L) (n : ℕ) : R.coeff n ∈ L := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    cases n with
    | zero => rw [h0]; exact L.one_mem
    | succ m =>
      let middle : K := ∑ i ∈ range m, R.coeff (i+1) * R.coeff (m-i)
      have hmid : middle ∈ L := by
        apply L.sum_mem
        intro i hi
        have hi' := mem_range.mp hi
        apply L.mul_mem <;> apply ih <;> omega
      have hcoeff : (R*R).coeff (m+1) = middle + 2*R.coeff (m+1) := by
        rw [coeff_mul, Finset.Nat.sum_antidiagonal_eq_sum_range_succ_mk,
          Finset.sum_range_succ, Finset.sum_range_succ']
        simp [middle, h0, Nat.add_sub_add_right]
        ring
      have he : R.coeff (m+1) = ((R*R).coeff (m+1) - middle)/2 := by
        rw [hcoeff]
        ring
      rw [he]
      apply L.div_mem (L.sub_mem (h _) hmid)
      rw [show (2 : K) = 1 + 1 by ring]
      exact L.add_mem L.one_mem L.one_mem

/-- A monic square root over any characteristic-zero field descends to the
rational coefficient field of its square. -/
theorem monic_square_descends_rat (S : K[X]) (P : ℚ[X]) (hS : S.Monic)
    (hsq : S^2 = P.map (algebraMap ℚ K)) :
    ∃ R : ℚ[X], R.Monic ∧ R.map (algebraMap ℚ K) = S ∧ R^2 = P := by
  let f := algebraMap ℚ K
  let L := f.fieldRange
  have hs (i : ℕ) : (S*S).coeff i ∈ L := by
    rw [← pow_two, hsq, coeff_map]
    exact f.mem_fieldRange_self _
  have hrev (i : ℕ) : (S.reverse*S.reverse).coeff i ∈ L := by
    rw [← reverse_mul_of_domain, coeff_reverse]
    exact hs _
  have h0 : S.reverse.coeff 0 = 1 := by rw [coeff_zero_reverse, hS.leadingCoeff]
  have hl : S ∈ lifts f := by
    rw [lifts_iff_coeff_lifts]
    intro i
    have hi := coeff_mem_of_square L S.reverse h0 hrev (revAt S.natDegree i)
    change S.coeff i ∈ L
    simpa only [coeff_reverse, revAt_invol] using hi
  obtain ⟨R,hR⟩ := (mem_lifts S).mp hl
  refine ⟨R, Polynomial.monic_of_injective f.injective (hR ▸ hS), hR, ?_⟩
  apply Polynomial.map_injective f f.injective
  simpa only [Polynomial.map_pow, hR] using hsq

end
end EulerDescent
