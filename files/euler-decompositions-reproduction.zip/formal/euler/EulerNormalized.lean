import Mathlib.Algebra.Polynomial.Eval.Coeff
import Mathlib.Data.Nat.Choose.Sum
import Mathlib.Data.ZMod.Basic
import Mathlib.Tactic.Ring
import Mathlib.Tactic.LinearCombination

/-! Normalized Euler polynomials over arbitrary coefficient rings. The recursive
definition has integral coefficients; in characteristic zero the central shift
identity characterizes the classical normalized Euler polynomial. -/
namespace EulerNormalized
open Polynomial Finset
open scoped BigOperators

/-- The inverse of averaging the shifts ±1 on the monomial basis. -/
noncomputable def A (R : Type*) [CommRing R] (n : ℕ) : R[X] :=
  X^n - ∑ j : Fin n, if Even (n-j.val) then
      (n.choose j.val : R[X]) * A R j.val else 0
termination_by n
decreasing_by exact j.isLt

private theorem plusMinus (R : Type*) [CommRing R] (x : R) (n : ℕ) :
    (x+1)^n+(x-1)^n =
      2*(x^n + ∑ j : Fin n, if Even (n-j.val) then (n.choose j.val : R)*x^j.val else 0) := by
  rw [show x-1=x+(-1) from by ring, add_pow, add_pow, ← Finset.sum_add_distrib]
  have step (j : ℕ) : x^j*1^(n-j)*(n.choose j : R) + x^j*(-1)^(n-j)*(n.choose j : R)
      = 2*(if Even (n-j) then (n.choose j : R)*x^j else 0) := by
    rcases Nat.even_or_odd (n-j) with h | h
    · simp [h, h.neg_one_pow]; ring
    · have hn : ¬Even (n-j) := by rintro ⟨k,hk⟩; obtain ⟨i,hi⟩ := h; omega
      simp [hn, h.neg_one_pow]
  simp_rw [step]
  rw [← Finset.mul_sum, Finset.sum_range_succ, ← Fin.sum_univ_eq_sum_range]
  simp [add_comm]

/-- This identity, and integrality of the definition, fix the normalization
A_n(z)=2^n E_n((z+1)/2) over characteristic zero. -/
theorem centralShift {R : Type*} [CommRing R] (n : ℕ) (x : R) :
    (A R n).eval (x+1)+(A R n).eval (x-1)=2*x^n := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    rw [A]
    simp only [eval_sub, eval_pow, eval_X, eval_finsetSum, apply_ite (eval _), eval_mul,
      eval_natCast, eval_zero]
    have sums :
      (∑ j : Fin n, if Even (n-j.val) then (n.choose j.val : R)*(A R j.val).eval (x+1) else 0) +
      (∑ j : Fin n, if Even (n-j.val) then (n.choose j.val : R)*(A R j.val).eval (x-1) else 0) =
      2*(∑ j : Fin n, if Even (n-j.val) then (n.choose j.val : R)*x^j.val else 0) := by
      rw [← Finset.sum_add_distrib, Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      split_ifs
      · linear_combination (n.choose j.val : R)*ih j.val j.isLt
      · ring
    linear_combination plusMinus R x n - sums

theorem forwardShift {R : Type*} [CommRing R] (n : ℕ) (x : R) :
    (A R n).eval x+(A R n).eval (x+2)=2*(x+1)^n := by
  simpa only [show x+1+1=x+2 from by ring, add_sub_cancel_right, add_comm ((A R n).eval x)] using
    centralShift n (x+1)


private theorem telescope {R : Type*} [CommRing R] (n k : ℕ) (x : R) :
    2 * (∑ j ∈ range k, (-1:R)^j * (x + 2*(j:R)+1)^n) =
    (A R n).eval x - (-1:R)^k * (A R n).eval (x+2*(k:R)) := by
  induction k with
  | zero => simp
  | succ k ih =>
    rw [Finset.sum_range_succ, mul_add, ih, pow_succ, Nat.cast_succ]
    have h := forwardShift n (x+2*(k:R))
    rw [show x+2*((k:R)+1)=x+2*(k:R)+2 from by ring]
    linear_combination -(-1:R)^k*h

/-- Reduction of the classical difference equation yields the alternating sum
as an identity even over extensions of the prime field. -/
theorem alternating {p : ℕ} {R : Type*} [CommRing R] [IsDomain R] [CharP R p]
    (hp : Odd p) (h2 : (2:R) ≠ 0) (n : ℕ) (x : R) :
    (A R n).eval x = ∑ j ∈ range p, (-1:R)^j * (x+2*(j:R)+1)^n := by
  have h := telescope n p x
  rw [hp.neg_one_pow,CharP.cast_eq_zero R p,mul_zero,add_zero] at h
  apply mul_left_cancel₀ h2
  linear_combination -h

/-- Coefficient maps commute with the normalized sequence. -/
theorem map_A {R S : Type*} [CommRing R] [CommRing S] (g : R →+* S) (n : ℕ) :
    (A R n).map g = A S n := by
  induction n using Nat.strong_induction_on with
  | h n ih =>
    rw [A, A]
    simp only [Polynomial.map_sub, Polynomial.map_pow, map_X, Polynomial.map_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    split_ifs <;> simp [Polynomial.map_mul, ih j j.isLt]

end EulerNormalized
