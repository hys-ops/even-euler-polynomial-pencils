import EulerDecomposition
import EulerEight
import EulerIntegralNormalization
import Mathlib.Algebra.Polynomial.BigOperators
import Mathlib.Tactic.LinearCombination

/-! Even ordinary Euler polynomials over the integers. Averaging (x²+x)^m and
(x²−x)^m gives a monic polynomial in x² with integer coefficients. Triangular
inversion in the power basis therefore requires no integer denominators. -/
namespace EulerEvenIntegral
open Polynomial Finset
open scoped BigOperators

noncomputable def evenEuler (R : Type*) [CommRing R] (m : ℕ) : R[X] :=
  (X^2-X)^m - ∑ j : Fin m, if Even (m-j.val) then
    C (m.choose j.val:R)*evenEuler R ((m+j.val)/2) else 0
termination_by m
decreasing_by have := j.isLt; omega

private theorem power_shift {R : Type*} [CommRing R] (m : ℕ) (x : R) :
    (x^2+x)^m+(x^2-x)^m = 2*(x^(2*m)+∑ j : Fin m, if Even (m-j.val)
    then (m.choose j.val:R)*x^(2*((m+j.val)/2)) else 0) := by
  rw [show x^2+x=x*(x+1) by ring, show x^2-x=x*(x+(-1)) by ring,
    mul_pow, mul_pow, ← mul_add, add_pow, add_pow, ← Finset.sum_add_distrib,Finset.mul_sum]
  have step (j : ℕ) (hj : j ≤ m) : x^m *
      (x^j*1^(m-j)*(m.choose j:R) + x^j*(-1)^(m-j)*(m.choose j:R)) =
      2*(if Even (m-j) then (m.choose j:R)*x^(2*((m+j)/2)) else 0) := by
    rcases Nat.even_or_odd (m-j) with h | h
    · have hz : m+j=2*((m+j)/2) := by obtain ⟨k,hk⟩ := h; omega
      simp only [h.neg_one_pow,one_pow,mul_one,if_pos h]
      rw [← hz,pow_add]
      ring
    · have hn : ¬Even (m-j) := by obtain ⟨k,hk⟩ := h; rintro ⟨l,hl⟩; omega
      simp [hn,h.neg_one_pow]
  calc
    _ = ∑ j ∈ Finset.range (m+1), 2*(if Even (m-j) then
        (m.choose j:R)*x^(2*((m+j)/2)) else 0) := by
      apply Finset.sum_congr rfl; intro j hj; exact step j (by simpa using hj)
    _ = _ := by
      rw [← Finset.mul_sum,Finset.sum_range_succ,← Fin.sum_univ_eq_sum_range]
      simp [add_comm,show (m+m)/2=m by omega]

theorem shift {R : Type*} [CommRing R] (m : ℕ) (x : R) :
    (evenEuler R m).eval (x+1) + (evenEuler R m).eval x = 2*x^(2*m) := by
  induction m using Nat.strong_induction_on with
  | h m ih =>
    rw [evenEuler.eq_1]
    simp only [eval_sub,eval_pow,eval_X,eval_finsetSum,apply_ite (eval _),eval_mul,eval_C,eval_zero]
    rw [show (x+1)^2-(x+1) = x^2+x by ring]
    have hsum :
        (∑ j : Fin m, if Even (m-j.val) then (m.choose j.val:R)*(evenEuler R ((m+j.val)/2)).eval (x+1) else 0) +
        (∑ j : Fin m, if Even (m-j.val) then (m.choose j.val:R)*(evenEuler R ((m+j.val)/2)).eval x else 0) =
        2*∑ j : Fin m, if Even (m-j.val) then (m.choose j.val:R)*x^(2*((m+j.val)/2)) else 0 := by
      rw [← Finset.sum_add_distrib,Finset.mul_sum]
      apply Finset.sum_congr rfl
      intro j _
      split_ifs
      · linear_combination (m.choose j.val:R)*ih ((m+j.val)/2) (by have := j.isLt; omega)
      · ring
    linear_combination power_shift m x - hsum

theorem map_evenEuler {R S : Type*} [CommRing R] [CommRing S] (g : R →+* S) (m : ℕ) :
    (evenEuler R m).map g = evenEuler S m := by
  induction m using Nat.strong_induction_on with
  | h m ih =>
    rw [evenEuler.eq_1 R m,evenEuler.eq_1 S m]
    simp only [Polynomial.map_pow, Polynomial.map_sub, map_X, Polynomial.map_sum]
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    split_ifs <;> simp [Polynomial.map_mul, ih ((m+j.val)/2) (by have := j.isLt; omega)]


private theorem leading_data (m : ℕ) :
    (evenEuler ℤ m).natDegree = 2*m ∧
    (evenEuler ℤ m).Monic ∧ (evenEuler ℤ m).nextCoeff = -(m:ℤ) := by
  induction m using Nat.strong_induction_on with
  | h m ih =>
    by_cases hm : m=0
    · subst m; rw [evenEuler.eq_1]; simp [nextCoeff]
    let B : ℤ[X] := ∑ j : Fin m, if Even (m-j.val) then
      C (m.choose j.val:ℤ)*evenEuler ℤ ((m+j.val)/2) else 0
    have hb : B.natDegree ≤ 2*(m-1) := by
      apply natDegree_sum_le_of_forall_le
      intro j _
      have hsmall : (m+j.val)/2 < m := by have := j.isLt; omega
      split_ifs
      · apply (natDegree_C_mul_le _ _).trans
        rw [(ih _ hsmall).1]
        omega
      · simp
    let M : ℤ[X] := (X^2-X)^m
    have hM : M = X^m*(X+C (-1:ℤ))^m := by
      dsimp [M]
      rw [← mul_pow]
      congr 1
      simp; ring
    have hmon : M.Monic := by
      rw [hM]
      exact (monic_X_pow m).mul ((monic_X_add_C (-1:ℤ)).pow m)
    have hdeg : M.natDegree = 2*m := by
      rw [hM,(monic_X_pow m).natDegree_mul ((monic_X_add_C (-1:ℤ)).pow m),
        natDegree_X_pow,(monic_X_add_C (-1:ℤ)).natDegree_pow,natDegree_X_add_C]
      omega
    have hmcoeff : M.coeff (2*m-1) = -(m:ℤ) := by
      rw [hM,coeff_X_pow_mul', if_pos (show m ≤ 2*m-1 by omega),
        show 2*m-1-m = m-1 from by omega, coeff_X_add_C_pow,
        show m-(m-1)=1 from by omega]
      rw [← Nat.choose_symm (show m-1 ≤ m by omega),
        show m-(m-1)=1 from by omega, Nat.choose_one_right]
      simp
    have hB1 : B.coeff (2*m-1) = 0 := coeff_eq_zero_of_natDegree_lt (by omega)
    have hB2 : B.coeff (2*m)=0 := coeff_eq_zero_of_natDegree_lt (by omega)
    have hEq : evenEuler ℤ m = M-B := evenEuler.eq_1 ℤ m
    have hd : (evenEuler ℤ m).natDegree=2*m := by
      rw [hEq,natDegree_sub_eq_left_of_natDegree_lt (by omega),hdeg]
    refine ⟨hd,?_,?_⟩
    · change (evenEuler ℤ m).coeff (evenEuler ℤ m).natDegree=1
      rw [hd,hEq,coeff_sub,hB2,sub_zero,← hdeg,hmon.coeff_natDegree]
    · rw [nextCoeff_of_natDegree_pos (by omega),hd,hEq,coeff_sub,hB1,sub_zero,hmcoeff]

theorem evenEuler_natDegree (m : ℕ) : (evenEuler ℤ m).natDegree = 2*m :=
  (leading_data m).1

theorem evenEuler_monic (m : ℕ) : (evenEuler ℤ m).Monic := (leading_data m).2.1

theorem evenEuler_nextCoeff (m : ℕ) : (evenEuler ℤ m).nextCoeff = -(m:ℤ) :=
  (leading_data m).2.2

/-- The defining shift identifies these integral models with the classical
even Euler polynomials over every field of characteristic zero. -/
theorem integral_model {K : Type*} [Field K] [CharZero K] (m : ℕ) (E : K[X])
    (hE : ∀ x : K, E.eval (x+1)+E.eval x = 2*x^(2*m)) :
    E = (evenEuler ℤ m).map (Int.castRingHom K) := by
  rw [map_evenEuler]
  exact EulerEight.shift_sum_injective _ _ fun x => (hE x).trans (shift m x).symm


/-- For ordinary even Euler polynomials defined by their shift identities and
a reduced rational parameter c/D whose denominator exceeds one, an inner
factor of degree at least three forces denominator four and degree two mod four. -/
theorem ordinary_denominator (m D : ℕ) (c : ℤ) (E H U V : ℚ[X])
    (hm : 1 ≤ m) (hd : 1 < D) (cop : c.natAbs.Coprime D)
    (he : ∀ x : ℚ, E.eval (x+1)+E.eval x = 2*x^(2*m))
    (hh : ∀ x : ℚ, H.eval (x+1)+H.eval x = 2*x^(2*(m-1)))
    (hu : 2 ≤ U.natDegree) (hv : 3 ≤ V.natDegree)
    (hcomp : U.comp V = E+C ((c:ℚ)/(D:ℚ))*H) :
    D=4 ∧ 2*m%4=2 := by
  let g : ℤ →+* ℚ := algebraMap ℤ ℚ
  have he' : E = (evenEuler ℤ m).map g := integral_model m E he
  have hh' : H = (evenEuler ℤ (m-1)).map g := integral_model _ H hh
  have hD : (D:ℚ) ≠ 0 := by exact_mod_cast (by omega : D ≠ 0)
  have hmap :
      (C (D:ℤ)*evenEuler ℤ m + C c*evenEuler ℤ (m-1)).map g =
      (C (D:ℚ)*U).comp V := by
    rw [Polynomial.map_add,Polynomial.map_mul,Polynomial.map_mul,map_C,map_C,← he',← hh',
      mul_comp,C_comp,hcomp]
    change C (D:ℚ)*E+C (c:ℚ)*H = C (D:ℚ)*(E+C ((c:ℚ)/(D:ℚ))*H)
    rw [mul_add,← mul_assoc,← map_mul]
    congr 2
    field_simp
  have hdu : (C (D:ℚ)*U).natDegree=U.natDegree := natDegree_C_mul hD
  have hres := EulerIntegralNormalization.rational_pencil_obstruction D c (evenEuler ℤ m)
    (evenEuler ℤ (m-1)) (C (D:ℚ)*U) V hd cop (evenEuler_monic _) (evenEuler_monic _)
    (by simp only [evenEuler_natDegree]; omega)
    (by rw [evenEuler_nextCoeff,evenEuler_natDegree]; simp)
    (hdu.symm ▸ hu) hv hmap
  simpa only [evenEuler_natDegree] using hres

theorem evenEuler_reflect {R : Type*} [CommRing R] (m : ℕ) (x : R) :
    (evenEuler R m).eval (1-x) = (evenEuler R m).eval x := by
  induction m using Nat.strong_induction_on with
  | h m ih =>
    rw [evenEuler.eq_1]
    simp only [eval_sub,eval_pow,eval_X,eval_finsetSum,apply_ite (eval _),eval_mul,eval_C,eval_zero,
      show (1-x)^2-(1-x)=x^2-x by ring]
    congr 1
    apply Finset.sum_congr rfl
    intro j _
    split_ifs <;> first | rw [ih ((m+j.val)/2) (by have := j.isLt; omega)] | rfl

/-- A quadratic inner factor must have the same reflection axis as its
nonconstant composite. -/
theorem quadratic_inner {K : Type*} [Field K] [CharZero K]
    (U V : K[X]) (hu : 0 < U.natDegree) (hv : V.natDegree=2)
    (h : ∀ x : K, (U.comp V).eval (1-x) = (U.comp V).eval x) :
    ∃ a b : K, a ≠ 0 ∧ V=C a*(X^2-X)+C b := by
  let a := V.coeff 2
  let b := V.coeff 1
  have ha : a ≠ 0 := by
    dsimp [a]; rw [← hv, coeff_natDegree]
    apply leadingCoeff_ne_zero.mpr
    intro hn
    simp [hn] at hv
  have heval (x : K) : V.eval x = V.coeff 0 + b*x + a*x^2 := by
    rw [eval_eq_sum_range' (n:=3) (by omega)]
    simp [Finset.sum_range_succ,b,a]
  let q := b/a
  have hq : q*a=b := by dsimp [q]; field_simp
  have ht : 1+q=0 := by
    apply EulerDecomposition.zero_period (U.comp V) (by rw [natDegree_comp,hv]; omega)
    intro x
    rw [← h (x+(1+q)), eval_comp, eval_comp, heval, heval]
    congr 1
    linear_combination (2*x+q)*hq
  refine ⟨a,V.coeff 0,ha,Polynomial.funext fun x => ?_⟩
  simp only [heval,eval_add,eval_mul,eval_C,eval_sub,eval_pow,eval_X]
  linear_combination (x*a)*ht - x*hq

#print axioms ordinary_denominator
#print axioms integral_model

end EulerEvenIntegral
