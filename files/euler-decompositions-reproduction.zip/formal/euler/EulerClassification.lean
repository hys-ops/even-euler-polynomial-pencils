import EulerRational
import EulerDecomposition
import EulerIdentification
import EulerSmall
import EulerEight

/-! From a square obstruction for normalized Euler polynomials to the
decomposition statement for the classical shift-defined Euler polynomials. -/
namespace EulerClassification
open Polynomial EulerNormalized
noncomputable section

def full (R : Type*) [CommRing R] (p : ℕ) (d : R) : R[X] :=
  A R (2*p) + C d * A R (2*p-2)

private theorem zero_removed (p : ℕ) (d : ℚ) :
    full ℚ p d - C ((full ℚ p d).eval 0) = EulerSmall.pencil ℚ p d := by
  simp only [full,EulerSmall.pencil,EulerSmall.delta,eval_add,eval_mul,eval_C,C_add,C_mul]
  ring

private theorem central_shape (m : ℕ) (hm : 0 < m) :
    (A ℚ m).Monic ∧ (A ℚ m).natDegree=m := by
  let f := algebraMap ℤ ℚ
  have he : (EulerPrime.centered m).map f = A ℚ m := by
    rw [EulerIdentification.centered_eq_A,map_A]
  have hd : (EulerPrime.centered m).natDegree=m := by
    rw [EulerPrime.centered,natDegree_add_C,EulerPrime.delta_natDegree hm]
  have hl : (EulerPrime.centered m).Monic := by
    unfold EulerPrime.centered
    rw [Monic.def,leadingCoeff_add_of_degree_lt']
    · exact EulerPrime.delta_monic hm
    · apply degree_C_le.trans_lt
      rw [← natDegree_pos_iff_degree_pos,EulerPrime.delta_natDegree hm]; exact hm
  rw [← he]
  exact ⟨hl.map f,(hl.natDegree_map f).trans hd⟩

private theorem central_even (m : ℕ) (hm : Even m) : (A ℚ m).comp (-X) = A ℚ m := by
  have hd : (EulerPrime.delta m).comp (-X) = EulerPrime.delta m := by
    ext k
    rw [show (-X : ℤ[X]) = C (-1) * X by simp,comp_C_mul_X_coeff]
    rcases Nat.even_or_odd k with hk | hk
    · rw [hk.neg_one_pow,mul_one]
    · rw [EulerPrime.delta_coeff_even hm hk,zero_mul]
  have he : (EulerPrime.centered m).comp (-X) = EulerPrime.centered m := by
    simp only [EulerPrime.centered,add_comp,C_comp,hd]
  have hmap := congrArg (Polynomial.map (algebraMap ℤ ℚ)) he
  simpa only [Polynomial.map_comp,Polynomial.map_neg,Polynomial.map_X,
    EulerIdentification.centered_eq_A,map_A] using hmap

private theorem full_shape {p : ℕ} (hp : 2 < p) (d : ℚ) :
    (full ℚ p d).Monic ∧ (full ℚ p d).natDegree=2*p ∧ (full ℚ p d).comp (-X)=full ℚ p d := by
  obtain ⟨h1,d1⟩ := central_shape (2*p) (by omega)
  obtain ⟨_,d2⟩ := central_shape (2*p-2) (by omega)
  have dl : (C d * A ℚ (2*p-2)).degree < (A ℚ (2*p)).degree := by
    apply degree_lt_degree
    apply lt_of_le_of_lt (natDegree_C_mul_le _ _)
    omega
  refine ⟨?_, ?_, ?_⟩
  · rw [full,Monic.def,leadingCoeff_add_of_degree_lt' dl]; exact h1
  · rw [full,natDegree_eq_of_degree_eq (degree_add_eq_left_of_degree_lt dl),d1]
  · simp only [full,add_comp,mul_comp,C_comp,
      central_even _ (show Even (2*p) from ⟨p,by omega⟩),
      central_even _ (show Even (2*p-2) from ⟨p-1,by omega⟩)]

variable {K : Type*} [Field K] [CharZero K]

private theorem normalized_of_obstruction {p : ℕ} [Fact p.Prime] (hp : 2<p)
    (d : ℚ) (U V : K[X]) (h : U.comp V=full K p (d:K))
    (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree)
    (noRoot : ∀ S : ℚ[X], S.Monic → S.comp (-X)= -S → S^2 ≠ EulerSmall.pencil ℚ p d) :
    ∃ a b : K, a ≠ 0 ∧ V=C a*X^2+C b := by
  have hm : (full ℚ p d).map (algebraMap ℚ K) = full K p (d:K) := by
    simp [full,Polynomial.map_add,Polynomial.map_mul,map_A]
  obtain ⟨hM,hd,he⟩ := full_shape hp d
  rcases EulerDecomposition.centered_or_rational_square (Fact.out : p.Prime) (by omega)
    (full ℚ p d) U V (h.trans hm.symm) hM hd he hu hv with hg | ⟨S,hS,_,ho,hs⟩
  · exact hg
  · exact ((noRoot S hS ho) (hs.trans (zero_removed p d))).elim

/-- Classical Euler polynomial in terms of the centered Euler polynomial. -/
def classicalEuler (m : ℕ) : K[X] :=
  C ((2 : K)^m)⁻¹ * (A K m).comp (C 2*X - 1)

theorem classical_shift (m : ℕ) (x : K) :
    (classicalEuler m).eval (x+1)+(classicalEuler m).eval x=2*x^m := by
  simp only [classicalEuler,eval_mul,eval_C,eval_comp,eval_sub,eval_X,eval_one]
  rw [show 2*(x+1)-1=2*x+1 by ring, ← mul_add, centralShift m (2*x),mul_pow]
  have hn : (2:K)^m ≠ 0 := pow_ne_zero _ (by norm_num)
  field_simp

private def inverseCoord : K[X] := C (2:K)⁻¹ * X + C (2:K)⁻¹

private theorem inverse_eval (z : K) : inverseCoord.eval z = (z+1)/2 := by
  simp [inverseCoord]; ring

private theorem change_coord (m : ℕ) (z : K) :
    (2:K)^m * (classicalEuler m).eval (inverseCoord.eval z) = (A K m).eval z := by
  rw [inverse_eval]
  simp only [classicalEuler,eval_mul,eval_C,eval_comp,eval_sub,eval_X,eval_one]
  rw [show 2*((z+1)/2)-1=z by ring]
  have hn : (2:K)^m ≠ 0 := pow_ne_zero _ (by norm_num)
  field_simp

/-- The conditional version used to connect the algebraic classification to
the finite-field and denominator arguments. -/
theorem shift_defined_of_obstruction {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (c : ℚ) (E F U V : K[X]) (hE : ∀ x : K, E.eval (x+1)+E.eval x=2*x^(2*p))
    (hF : ∀ x : K, F.eval (x+1)+F.eval x=2*x^(2*p-2))
    (hcomp : U.comp V=E+C (c:K)*F) (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree)
    (noRoot : ∀ S : ℚ[X], S.Monic → S.comp (-X)= -S →
      S^2 ≠ EulerSmall.pencil ℚ p (4*c)) :
    ∃ a b : K, a ≠ 0 ∧ V=C a*(X^2-X)+C b := by
  have e1 : E = classicalEuler (2*p) :=
    EulerEight.shift_sum_injective _ _ fun x => (hE x).trans (classical_shift _ x).symm
  have e2 : F = classicalEuler (2*p-2) :=
    EulerEight.shift_sum_injective _ _ fun x => (hF x).trans (classical_shift _ x).symm
  subst E; subst F
  let u := C ((2:K)^(2*p)) * U
  let v := V.comp inverseCoord
  have hdcoord : (inverseCoord : K[X]).natDegree=1 := by
    unfold inverseCoord; rw [natDegree_add_C,natDegree_C_mul (by norm_num),natDegree_X]
  have hu' : 2 ≤ u.natDegree := by unfold u; rw [natDegree_C_mul (pow_ne_zero (2*p) (by norm_num : (2:K)≠0))]; exact hu
  have hv' : 2 ≤ v.natDegree := by simpa [v,natDegree_comp,hdcoord] using hv
  have hsc : (2:K)^(2*p) = 4*(2:K)^(2*p-2) := by
    calc
      _ = (2:K)^((2*p-2)+2) := by congr 1; omega
      _ = _ := by rw [pow_add]; ring
  have ht : u.comp v=full K p ((4*c:ℚ):K) := by
    apply Polynomial.funext
    intro z
    have h := congrArg (fun W : K[X] => W.eval (inverseCoord.eval z)) hcomp
    simp only [eval_comp,eval_add,eval_mul,eval_C] at h
    simp only [u,v,full,eval_comp,eval_mul,eval_C,eval_add]
    rw [h,mul_add,change_coord]
    push_cast
    linear_combination (4*(c:K))*(change_coord (2*p-2) z) +
      ((c:K)*(classicalEuler (2*p-2)).eval (inverseCoord.eval z))*hsc
  obtain ⟨a,b,ha,hq⟩ := normalized_of_obstruction hp (4*c) u v ht hu' hv' noRoot
  refine ⟨4*a,a+b,mul_ne_zero (by norm_num) ha, Polynomial.funext (fun x => ?_)⟩
  have hh := congrArg (fun P : K[X] => P.eval (2*x-1)) hq
  simp only [v,eval_comp,inverse_eval,eval_add,eval_mul,eval_C,eval_pow,eval_X] at hh
  rw [show (2*x-1+1)/2=x by ring] at hh
  simp only [eval_add,eval_mul,eval_C,eval_sub,eval_pow,eval_X]
  rw [hh]; ring

/-- Pintér–Rakaczki Conjecture 1 for degree twice any odd prime: the actual
Euler inputs over an arbitrary characteristic-zero field are specified by
their classical shift identities; every nonlinear inner factor has the
standard quadratic shape up to an invertible affine change. -/
theorem eulerTwicePrime_unique_inner {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (c : ℚ) (E F U V : K[X])
    (hE : ∀ x : K, E.eval (x+1)+E.eval x=2*x^(2*p))
    (hF : ∀ x : K, F.eval (x+1)+F.eval x=2*x^(2*p-2))
    (hcomp : U.comp V=E+C (c:K)*F) (hu : 2 ≤ U.natDegree) (hv : 2 ≤ V.natDegree) :
    ∃ a b : K, a ≠ 0 ∧ V=C a*(X^2-X)+C b :=
  shift_defined_of_obstruction hp c E F U V hE hF hcomp hu hv
    (fun S hS ho => EulerRational.noOddSquare hp (4*c) S hS ho)

/-- In characteristic zero a shift-defined Euler polynomial of even degree
is invariant under reflection in 1/2. -/
private theorem euler_symmetric (m : ℕ) (hm : Even m) (E : K[X])
    (h : ∀ x : K, E.eval (x+1)+E.eval x=2*x^m) (x : K) :
    E.eval (1-x)=E.eval x := by
  have hp : E.comp (1-X)=E := by
    apply EulerEight.shift_sum_injective
    intro y
    simp only [eval_comp,eval_sub,eval_X,eval_one]
    rw [show 1-(y+1) = -y by ring,show 1-y = -y+1 by ring,add_comm, h (-y),h y,hm.neg_pow]
  have he := congrArg (fun P : K[X] => P.eval x) hp
  simpa only [eval_comp,eval_sub,eval_one,eval_X] using he

theorem standard_exists (H : K[X]) (hh : ∀ x : K, H.eval (1-x)=H.eval x) :
    ∃ F : K[X], F.comp (X^2-X)=H := by
  let T := H.comp inverseCoord
  have he : T.comp (-X)=T := by
    apply Polynomial.funext
    intro z
    simp only [T,eval_comp,eval_neg,eval_X,inverse_eval]
    rw [show (-z+1)/2=1-(z+1)/2 by ring,hh]
  have hx : (contract 2 T).comp (X^2) = T := by
    rw [← expand_eq_comp_X_pow]
    ext n
    rw [coeff_expand (by decide : 0 < 2)]
    split_ifs with hdiv
    · rw [coeff_contract (by decide : 2 ≠ 0),Nat.div_mul_cancel hdiv]
    · have hOdd : Odd n := by rcases Nat.even_or_odd n with hn | hn; exact (hdiv (even_iff_two_dvd.mp hn)).elim; exact hn
      have hh' := congrArg (fun P : K[X] => P.coeff n) he
      change (T.comp (-X)).coeff n = T.coeff n at hh'
      rw [show (-X : K[X])=C (-1)*X by simp,comp_C_mul_X_coeff,hOdd.neg_one_pow] at hh'
      linear_combination hh'/2
  refine ⟨(contract 2 T).comp (C 4*X+1),Polynomial.funext (fun z => ?_)⟩
  have ht := congrArg (fun P : K[X] => P.eval (2*z-1)) hx
  simp only [eval_comp,eval_pow,eval_X,T,inverse_eval] at ht
  rw [show (2*z-1+1)/2=z by ring] at ht
  simp only [eval_comp,eval_pow,eval_X,eval_add,eval_mul,eval_C,eval_sub,eval_one]
  rw [show 4*(z^2-z)+1=(2*z-1)^2 by ring,ht]

theorem comp_cancel (A B T : K[X]) (hT : 0<T.natDegree)
    (he : A.comp T=B.comp T) : A=B := by
  have hh : (A-B).comp T=0 := by rw [sub_comp,he,sub_self]
  apply sub_eq_zero.mp
  apply (comp_eq_zero_iff.mp hh).resolve_right
  rintro ⟨_,h⟩
  have hh' := congrArg natDegree h
  simp at hh'
  omega

/-- A single standard outer polynomial exists, and every nonlinear
decomposition is equivalent to it by the affine interposed variable aX+b. -/
theorem eulerTwicePrime_complete {p : ℕ} [Fact p.Prime] (hp : 2 < p)
    (c : ℚ) (E F : K[X])
    (hE : ∀ x : K, E.eval (x+1)+E.eval x=2*x^(2*p))
    (hF : ∀ x : K, F.eval (x+1)+F.eval x=2*x^(2*p-2)) :
    ∃! G : K[X], G.comp (X^2-X)=E+C (c:K)*F ∧
      ∀ U V : K[X], U.comp V=E+C (c:K)*F → 2 ≤ U.natDegree → 2 ≤ V.natDegree →
        ∃ a b : K, a ≠ 0 ∧ V=(C a*X+C b).comp (X^2-X) ∧ G=U.comp (C a*X+C b) := by
  let T : K[X] := X^2-X
  have hT : 0 < T.natDegree := by
    unfold T; rw [natDegree_sub_eq_left_of_natDegree_lt]; all_goals simp
  obtain ⟨G,hG⟩ := standard_exists (E+C (c:K)*F) (by
    intro x
    simp only [eval_add,eval_mul,eval_C,euler_symmetric _ (show Even (2*p) from ⟨p,by omega⟩) E hE,
      euler_symmetric _ (show Even (2*p-2) from ⟨p-1,by omega⟩) F hF])
  refine ⟨G,⟨hG,?_⟩,?_⟩
  · intro U V he hu hv
    obtain ⟨a,b,ha,hV⟩ := eulerTwicePrime_unique_inner hp c E F U V hE hF he hu hv
    have hV' : V=(C a*X+C b).comp T := by simpa only [T,add_comp,mul_comp,C_comp,X_comp] using hV
    refine ⟨a,b,ha,hV',comp_cancel _ _ T hT ?_⟩
    rw [comp_assoc,← hV',he]
    exact hG
  · intro G' hG'
    exact comp_cancel G' G T hT (hG'.1.trans hG.symm)

#print axioms eulerTwicePrime_complete

#print axioms eulerTwicePrime_unique_inner
end
end EulerClassification
